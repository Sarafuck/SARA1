import {
  users, type User, type InsertUser,
  posts, type Post, type InsertPost,
  comments, type Comment, type InsertComment,
  friends, type Friend, type InsertFriend,
  loans, type Loan, type InsertLoan,
  payments, type Payment, type InsertPayment,
  fraudReports, type FraudReport, type InsertFraudReport,
  systemSettings, type SystemSetting, type InsertSystemSetting
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUid(uid: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  listUsers(): Promise<User[]>;

  // Post operations
  getPost(id: number): Promise<Post | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: number, updates: Partial<Post>): Promise<Post | undefined>;
  listPosts(limit?: number): Promise<Post[]>;
  listUserPosts(userId: number): Promise<Post[]>;
  likePost(id: number): Promise<Post | undefined>;
  dislikePost(id: number): Promise<Post | undefined>;

  // Comment operations
  getComment(id: number): Promise<Comment | undefined>;
  createComment(comment: InsertComment): Promise<Comment>;
  listPostComments(postId: number): Promise<Comment[]>;

  // Friend operations
  createFriendRequest(friendRequest: InsertFriend): Promise<Friend>;
  updateFriendRequest(id: number, status: string): Promise<Friend | undefined>;
  listUserFriends(userId: number): Promise<Friend[]>;
  listUserFriendRequests(userId: number): Promise<Friend[]>;

  // Loan operations
  getLoan(id: number): Promise<Loan | undefined>;
  createLoan(loan: InsertLoan): Promise<Loan>;
  updateLoan(id: number, updates: Partial<Loan>): Promise<Loan | undefined>;
  listUserLoans(userId: number): Promise<Loan[]>;
  listActiveLoans(): Promise<Loan[]>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  listLoanPayments(loanId: number): Promise<Payment[]>;
  listUserPayments(userId: number): Promise<Payment[]>;

  // Fraud report operations
  createFraudReport(report: InsertFraudReport): Promise<FraudReport>;
  updateFraudReport(id: number, status: string): Promise<FraudReport | undefined>;
  listFraudReports(): Promise<FraudReport[]>;
  searchFraudReports(type: string, value: string): Promise<FraudReport[]>;

  // System settings operations
  getSetting(key: string): Promise<SystemSetting | undefined>;
  updateSetting(key: string, value: string): Promise<SystemSetting>;
  getAllSettings(): Promise<SystemSetting[]>;
}

// In-memory implementation of the storage interface
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private friends: Map<number, Friend>;
  private loans: Map<number, Loan>;
  private payments: Map<number, Payment>;
  private fraudReports: Map<number, FraudReport>;
  private systemSettings: Map<string, SystemSetting>;

  private userIdCounter: number;
  private postIdCounter: number;
  private commentIdCounter: number;
  private friendIdCounter: number;
  private loanIdCounter: number;
  private paymentIdCounter: number;
  private fraudReportIdCounter: number;
  private systemSettingIdCounter: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.friends = new Map();
    this.loans = new Map();
    this.payments = new Map();
    this.fraudReports = new Map();
    this.systemSettings = new Map();

    this.userIdCounter = 1;
    this.postIdCounter = 1;
    this.commentIdCounter = 1;
    this.friendIdCounter = 1;
    this.loanIdCounter = 1;
    this.paymentIdCounter = 1;
    this.fraudReportIdCounter = 1;
    this.systemSettingIdCounter = 1;

    // Initialize default system settings
    this.initializeDefaultSettings();
  }

  private initializeDefaultSettings() {
    const defaultSettings = [
      { key: "interestRateLevel1", value: "5" },
      { key: "interestRateLevel2", value: "3" },
      { key: "interestRateLevel3", value: "2" },
      { key: "interestRateLevel4", value: "1" },
      { key: "registrationFee", value: "100" },
      { key: "levelUpThreshold2", value: "2" },
      { key: "levelUpThreshold3", value: "5" },
      { key: "levelUpThreshold4", value: "15" },
      { key: "xpOnTimePayment", value: "30" },
      { key: "xpLatePayment", value: "-20" },
      { key: "xpPostLike", value: "1" },
      { key: "xpPostDislike", value: "-5" },
      { key: "xpGiveLike", value: "-1" },
      { key: "xpGiveDislike", value: "-2" },
    ];

    for (const setting of defaultSettings) {
      this.updateSetting(setting.key, setting.value);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUid(uid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.uid === uid);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = {
      ...user,
      id,
      level: 1,
      xp: 0,
      onTimeRepayments: 0,
      registrationFee: false,
      createdAt: new Date(),
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async listUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Post operations
  async getPost(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async createPost(post: InsertPost): Promise<Post> {
    const id = this.postIdCounter++;
    const newPost: Post = {
      ...post,
      id,
      likes: 0,
      dislikes: 0,
      createdAt: new Date(),
    };
    this.posts.set(id, newPost);
    return newPost;
  }

  async updatePost(id: number, updates: Partial<Post>): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;

    const updatedPost = { ...post, ...updates };
    this.posts.set(id, updatedPost);
    return updatedPost;
  }

  async listPosts(limit: number = 50): Promise<Post[]> {
    const allPosts = Array.from(this.posts.values());
    allPosts.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return allPosts.slice(0, limit);
  }

  async listUserPosts(userId: number): Promise<Post[]> {
    const userPosts = Array.from(this.posts.values()).filter(post => post.userId === userId);
    userPosts.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return userPosts;
  }

  async likePost(id: number): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;

    const updatedPost = { ...post, likes: post.likes + 1 };
    this.posts.set(id, updatedPost);
    return updatedPost;
  }

  async dislikePost(id: number): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;

    const updatedPost = { ...post, dislikes: post.dislikes + 1 };
    this.posts.set(id, updatedPost);
    return updatedPost;
  }

  // Comment operations
  async getComment(id: number): Promise<Comment | undefined> {
    return this.comments.get(id);
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const id = this.commentIdCounter++;
    const newComment: Comment = {
      ...comment,
      id,
      createdAt: new Date(),
    };
    this.comments.set(id, newComment);
    return newComment;
  }

  async listPostComments(postId: number): Promise<Comment[]> {
    const postComments = Array.from(this.comments.values()).filter(comment => comment.postId === postId);
    postComments.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
    return postComments;
  }

  // Friend operations
  async createFriendRequest(friendRequest: InsertFriend): Promise<Friend> {
    const id = this.friendIdCounter++;
    const newFriendRequest: Friend = {
      ...friendRequest,
      id,
      createdAt: new Date(),
    };
    this.friends.set(id, newFriendRequest);
    return newFriendRequest;
  }

  async updateFriendRequest(id: number, status: string): Promise<Friend | undefined> {
    const friendRequest = this.friends.get(id);
    if (!friendRequest) return undefined;

    const updatedRequest = { ...friendRequest, status };
    this.friends.set(id, updatedRequest);
    return updatedRequest;
  }

  async listUserFriends(userId: number): Promise<Friend[]> {
    return Array.from(this.friends.values()).filter(
      friend => (friend.userId === userId || friend.friendId === userId) && friend.status === "accepted"
    );
  }

  async listUserFriendRequests(userId: number): Promise<Friend[]> {
    return Array.from(this.friends.values()).filter(
      friend => friend.friendId === userId && friend.status === "pending"
    );
  }

  // Loan operations
  async getLoan(id: number): Promise<Loan | undefined> {
    return this.loans.get(id);
  }

  async createLoan(loan: InsertLoan): Promise<Loan> {
    const id = this.loanIdCounter++;
    const newLoan: Loan = {
      ...loan,
      id,
      createdAt: new Date(),
    };
    this.loans.set(id, newLoan);
    return newLoan;
  }

  async updateLoan(id: number, updates: Partial<Loan>): Promise<Loan | undefined> {
    const loan = this.loans.get(id);
    if (!loan) return undefined;

    const updatedLoan = { ...loan, ...updates };
    this.loans.set(id, updatedLoan);
    return updatedLoan;
  }

  async listUserLoans(userId: number): Promise<Loan[]> {
    return Array.from(this.loans.values())
      .filter(loan => loan.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async listActiveLoans(): Promise<Loan[]> {
    return Array.from(this.loans.values())
      .filter(loan => loan.status === "active")
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Payment operations
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const id = this.paymentIdCounter++;
    const newPayment: Payment = {
      ...payment,
      id,
      paymentDate: new Date(),
    };
    this.payments.set(id, newPayment);
    return newPayment;
  }

  async listLoanPayments(loanId: number): Promise<Payment[]> {
    return Array.from(this.payments.values())
      .filter(payment => payment.loanId === loanId)
      .sort((a, b) => b.paymentDate.getTime() - a.paymentDate.getTime());
  }

  async listUserPayments(userId: number): Promise<Payment[]> {
    return Array.from(this.payments.values())
      .filter(payment => payment.userId === userId)
      .sort((a, b) => b.paymentDate.getTime() - a.paymentDate.getTime());
  }

  // Fraud report operations
  async createFraudReport(report: InsertFraudReport): Promise<FraudReport> {
    const id = this.fraudReportIdCounter++;
    const newReport: FraudReport = {
      ...report,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.fraudReports.set(id, newReport);
    return newReport;
  }

  async updateFraudReport(id: number, status: string): Promise<FraudReport | undefined> {
    const report = this.fraudReports.get(id);
    if (!report) return undefined;

    const updatedReport = { ...report, status };
    this.fraudReports.set(id, updatedReport);
    return updatedReport;
  }

  async listFraudReports(): Promise<FraudReport[]> {
    return Array.from(this.fraudReports.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async searchFraudReports(type: string, value: string): Promise<FraudReport[]> {
    const reports = Array.from(this.fraudReports.values());
    
    return reports.filter(report => {
      if (type === "phone" && report.phoneNumber) {
        return report.phoneNumber.includes(value);
      }
      if (type === "account" && report.bankAccount) {
        return report.bankAccount.includes(value);
      }
      if (type === "name" && report.fullName) {
        return report.fullName.toLowerCase().includes(value.toLowerCase());
      }
      return false;
    });
  }

  // System settings operations
  async getSetting(key: string): Promise<SystemSetting | undefined> {
    return this.systemSettings.get(key);
  }

  async updateSetting(key: string, value: string): Promise<SystemSetting> {
    const existingSetting = this.systemSettings.get(key);
    
    if (existingSetting) {
      const updatedSetting = { 
        ...existingSetting, 
        value, 
        updatedAt: new Date() 
      };
      this.systemSettings.set(key, updatedSetting);
      return updatedSetting;
    } else {
      const id = this.systemSettingIdCounter++;
      const newSetting: SystemSetting = {
        id,
        key,
        value,
        updatedAt: new Date(),
      };
      this.systemSettings.set(key, newSetting);
      return newSetting;
    }
  }

  async getAllSettings(): Promise<SystemSetting[]> {
    return Array.from(this.systemSettings.values());
  }
}

// Export the storage instance
export const storage = new MemStorage();
