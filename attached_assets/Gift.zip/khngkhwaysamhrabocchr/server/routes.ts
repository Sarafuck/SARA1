import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertPostSchema, 
  insertCommentSchema,
  insertFriendSchema,
  insertLoanSchema,
  insertPaymentSchema,
  insertFraudReportSchema,
  insertSystemSettingSchema
} from "@shared/schema";

// Helper function for validation
function validateRequest<T>(schema: z.ZodSchema<T>, data: unknown): T | null {
  try {
    return schema.parse(data);
  } catch (error) {
    return null;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req: Request, res: Response) => {
    const userData = validateRequest(insertUserSchema, req.body);
    if (!userData) {
      return res.status(400).json({ message: "Invalid user data" });
    }

    try {
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }

      // Check if Firebase UID already exists
      const existingUidUser = await storage.getUserByUid(userData.uid);
      if (existingUidUser) {
        return res.status(409).json({ message: "User already registered" });
      }

      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.get("/api/users/profile", async (req: Request, res: Response) => {
    const uid = req.query.uid as string;
    if (!uid) {
      return res.status(400).json({ message: "Missing uid parameter" });
    }

    try {
      const user = await storage.getUserByUid(uid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.updateUser(id, req.body);
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.post("/api/users/:id/pay-registration", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.registrationFee) {
        return res.status(400).json({ message: "Registration fee already paid" });
      }

      const updatedUser = await storage.updateUser(id, { registrationFee: true });
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update registration status" });
    }
  });

  // Post routes
  app.post("/api/posts", async (req: Request, res: Response) => {
    const postData = validateRequest(insertPostSchema, req.body);
    if (!postData) {
      return res.status(400).json({ message: "Invalid post data" });
    }

    try {
      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error) {
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  app.get("/api/posts", async (req: Request, res: Response) => {
    try {
      const posts = await storage.listPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.get("/api/users/:userId/posts", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const posts = await storage.listUserPosts(userId);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user posts" });
    }
  });

  app.post("/api/posts/:id/like", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid post ID" });
    }

    try {
      const post = await storage.getPost(id);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      const updatedPost = await storage.likePost(id);
      
      // Update user XP
      const likerUserId = req.body.userId;
      if (likerUserId) {
        const likerUser = await storage.getUser(likerUserId);
        const postUser = await storage.getUser(post.userId);
        
        const xpGiveLike = await storage.getSetting("xpGiveLike");
        const xpPostLike = await storage.getSetting("xpPostLike");
        
        if (likerUser && likerUserId !== post.userId) {
          await storage.updateUser(likerUserId, { 
            xp: likerUser.xp + parseInt(xpGiveLike?.value || "-1") 
          });
        }
        
        if (postUser) {
          await storage.updateUser(post.userId, { 
            xp: postUser.xp + parseInt(xpPostLike?.value || "1") 
          });
        }
      }
      
      res.json(updatedPost);
    } catch (error) {
      res.status(500).json({ message: "Failed to like post" });
    }
  });

  app.post("/api/posts/:id/dislike", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid post ID" });
    }

    try {
      const post = await storage.getPost(id);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      const updatedPost = await storage.dislikePost(id);
      
      // Update user XP
      const dislikerUserId = req.body.userId;
      if (dislikerUserId) {
        const dislikerUser = await storage.getUser(dislikerUserId);
        const postUser = await storage.getUser(post.userId);
        
        const xpGiveDislike = await storage.getSetting("xpGiveDislike");
        const xpPostDislike = await storage.getSetting("xpPostDislike");
        
        if (dislikerUser && dislikerUserId !== post.userId) {
          await storage.updateUser(dislikerUserId, { 
            xp: dislikerUser.xp + parseInt(xpGiveDislike?.value || "-2") 
          });
        }
        
        if (postUser) {
          await storage.updateUser(post.userId, { 
            xp: postUser.xp + parseInt(xpPostDislike?.value || "-5") 
          });
        }
      }
      
      res.json(updatedPost);
    } catch (error) {
      res.status(500).json({ message: "Failed to dislike post" });
    }
  });

  // Comment routes
  app.post("/api/posts/:postId/comments", async (req: Request, res: Response) => {
    const postId = parseInt(req.params.postId);
    if (isNaN(postId)) {
      return res.status(400).json({ message: "Invalid post ID" });
    }

    const commentData = validateRequest(insertCommentSchema, { ...req.body, postId });
    if (!commentData) {
      return res.status(400).json({ message: "Invalid comment data" });
    }

    try {
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }

      const comment = await storage.createComment(commentData);
      res.status(201).json(comment);
    } catch (error) {
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  app.get("/api/posts/:postId/comments", async (req: Request, res: Response) => {
    const postId = parseInt(req.params.postId);
    if (isNaN(postId)) {
      return res.status(400).json({ message: "Invalid post ID" });
    }

    try {
      const comments = await storage.listPostComments(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Friend routes
  app.post("/api/friends", async (req: Request, res: Response) => {
    const friendData = validateRequest(insertFriendSchema, req.body);
    if (!friendData) {
      return res.status(400).json({ message: "Invalid friend request data" });
    }

    try {
      const friend = await storage.createFriendRequest(friendData);
      res.status(201).json(friend);
    } catch (error) {
      res.status(500).json({ message: "Failed to create friend request" });
    }
  });

  app.patch("/api/friends/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid friend request ID" });
    }

    const { status } = req.body;
    if (!status || !["accepted", "rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    try {
      const updatedRequest = await storage.updateFriendRequest(id, status);
      if (!updatedRequest) {
        return res.status(404).json({ message: "Friend request not found" });
      }
      res.json(updatedRequest);
    } catch (error) {
      res.status(500).json({ message: "Failed to update friend request" });
    }
  });

  app.get("/api/users/:userId/friends", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const friends = await storage.listUserFriends(userId);
      res.json(friends);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch friends" });
    }
  });

  app.get("/api/users/:userId/friend-requests", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const requests = await storage.listUserFriendRequests(userId);
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch friend requests" });
    }
  });

  // Loan routes
  app.post("/api/loans", async (req: Request, res: Response) => {
    const loanData = validateRequest(insertLoanSchema, req.body);
    if (!loanData) {
      return res.status(400).json({ message: "Invalid loan data" });
    }

    try {
      const user = await storage.getUser(loanData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user has paid registration fee
      if (!user.registrationFee) {
        return res.status(400).json({ message: "Registration fee not paid" });
      }

      const loan = await storage.createLoan(loanData);
      res.status(201).json(loan);
    } catch (error) {
      res.status(500).json({ message: "Failed to create loan" });
    }
  });

  app.get("/api/users/:userId/loans", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const loans = await storage.listUserLoans(userId);
      res.json(loans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch loans" });
    }
  });

  app.patch("/api/loans/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid loan ID" });
    }

    try {
      const loan = await storage.getLoan(id);
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }

      const updatedLoan = await storage.updateLoan(id, req.body);
      res.json(updatedLoan);
    } catch (error) {
      res.status(500).json({ message: "Failed to update loan" });
    }
  });

  // Payment routes
  app.post("/api/payments", async (req: Request, res: Response) => {
    const paymentData = validateRequest(insertPaymentSchema, req.body);
    if (!paymentData) {
      return res.status(400).json({ message: "Invalid payment data" });
    }

    try {
      const loan = await storage.getLoan(paymentData.loanId);
      if (!loan) {
        return res.status(404).json({ message: "Loan not found" });
      }

      const payment = await storage.createPayment(paymentData);
      
      // Update loan information
      const newInstallmentsPaid = loan.installmentsPaid + 1;
      await storage.updateLoan(loan.id, { 
        installmentsPaid: newInstallmentsPaid,
        status: newInstallmentsPaid >= loan.duration ? "completed" : "active"
      });
      
      // If payment is on time, update user's on-time repayments and check for level up
      if (paymentData.onTime) {
        const user = await storage.getUser(paymentData.userId);
        if (user) {
          const newOnTimeRepayments = user.onTimeRepayments + 1;
          const updates: Partial<typeof user> = { 
            onTimeRepayments: newOnTimeRepayments 
          };
          
          // Add XP for on-time payment
          const xpSetting = await storage.getSetting("xpOnTimePayment");
          if (xpSetting) {
            updates.xp = user.xp + parseInt(xpSetting.value);
          }
          
          // Check for level up
          if (user.level === 1 && newOnTimeRepayments >= 2) {
            updates.level = 2;
          } else if (user.level === 2 && newOnTimeRepayments >= 5) {
            updates.level = 3;
          } else if (user.level === 3 && newOnTimeRepayments >= 15) {
            updates.level = 4;
          }
          
          await storage.updateUser(user.id, updates);
        }
      } else {
        // Handle late payment - deduct XP
        const user = await storage.getUser(paymentData.userId);
        if (user) {
          const xpSetting = await storage.getSetting("xpLatePayment");
          if (xpSetting) {
            await storage.updateUser(user.id, { 
              xp: user.xp + parseInt(xpSetting.value) 
            });
          }
        }
      }
      
      res.status(201).json(payment);
    } catch (error) {
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  app.get("/api/loans/:loanId/payments", async (req: Request, res: Response) => {
    const loanId = parseInt(req.params.loanId);
    if (isNaN(loanId)) {
      return res.status(400).json({ message: "Invalid loan ID" });
    }

    try {
      const payments = await storage.listLoanPayments(loanId);
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  // Fraud report routes
  app.post("/api/fraud-reports", async (req: Request, res: Response) => {
    const reportData = validateRequest(insertFraudReportSchema, req.body);
    if (!reportData) {
      return res.status(400).json({ message: "Invalid report data" });
    }

    try {
      const report = await storage.createFraudReport(reportData);
      res.status(201).json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to create report" });
    }
  });

  app.get("/api/fraud-reports", async (req: Request, res: Response) => {
    try {
      const reports = await storage.listFraudReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.get("/api/fraud-reports/search", async (req: Request, res: Response) => {
    const { type, value } = req.query;
    if (!type || !value || !["phone", "account", "name"].includes(type as string)) {
      return res.status(400).json({ message: "Invalid search parameters" });
    }

    try {
      const reports = await storage.searchFraudReports(type as string, value as string);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to search reports" });
    }
  });

  app.patch("/api/fraud-reports/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid report ID" });
    }

    const { status } = req.body;
    if (!status || !["verified", "rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    try {
      const updatedReport = await storage.updateFraudReport(id, status);
      if (!updatedReport) {
        return res.status(404).json({ message: "Report not found" });
      }
      res.json(updatedReport);
    } catch (error) {
      res.status(500).json({ message: "Failed to update report" });
    }
  });

  // System settings routes
  app.get("/api/settings", async (req: Request, res: Response) => {
    try {
      const settings = await storage.getAllSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.get("/api/settings/:key", async (req: Request, res: Response) => {
    const { key } = req.params;
    
    try {
      const setting = await storage.getSetting(key);
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch setting" });
    }
  });

  app.put("/api/settings/:key", async (req: Request, res: Response) => {
    const { key } = req.params;
    const { value } = req.body;
    
    if (value === undefined) {
      return res.status(400).json({ message: "Missing setting value" });
    }

    try {
      const updatedSetting = await storage.updateSetting(key, value.toString());
      res.json(updatedSetting);
    } catch (error) {
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
