import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { apiRequest } from "./queryClient";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string | number): string {
  const d = new Date(date);
  
  // Check if date is valid
  if (isNaN(d.getTime())) {
    return "Invalid date";
  }
  
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  const diffMonths = (now.getFullYear() - d.getFullYear()) * 12 + now.getMonth() - d.getMonth();
  
  // Format: less than a minute ago
  if (diffSecs < 60) {
    return "เมื่อสักครู่";
  }
  // Format: X minutes ago
  else if (diffMins < 60) {
    return `${diffMins} นาทีที่แล้ว`;
  }
  // Format: X hours ago
  else if (diffHours < 24) {
    return `${diffHours} ชั่วโมงที่แล้ว`;
  }
  // Format: X days ago
  else if (diffDays < 30) {
    return `${diffDays} วันที่แล้ว`;
  }
  // Format: X months ago
  else if (diffMonths < 12) {
    return `${diffMonths} เดือนที่แล้ว`;
  }
  // Format: date in thai format (day month year)
  else {
    const day = d.getDate();
    const month = getThaiMonth(d.getMonth());
    const year = d.getFullYear() + 543; // Convert to Buddhist Era
    return `${day} ${month} ${year}`;
  }
}

function getThaiMonth(month: number): string {
  const months = [
    "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.",
    "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."
  ];
  return months[month];
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("th-TH", {
    style: "currency",
    currency: "THB",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function calculateInstallment(amount: number, interestRate: number, duration: number): number {
  const interest = amount * (interestRate / 100);
  return (amount + interest) / duration;
}

export function getInitials(name: string): string {
  if (!name) return "";
  
  // For Thai names, get the first character
  if (/[\u0E00-\u0E7F]/.test(name)) {
    return name.charAt(0);
  }
  
  // For English names, get first letters of first and last name
  const nameParts = name.split(" ");
  if (nameParts.length === 1) {
    return nameParts[0].charAt(0).toUpperCase();
  }
  
  return (nameParts[0].charAt(0) + nameParts[nameParts.length - 1].charAt(0)).toUpperCase();
}

export function getLevelColor(level: number): string {
  switch (level) {
    case 1:
      return "text-gray-500";
    case 2:
      return "text-accent";
    case 3:
      return "text-primary";
    case 4:
      return "text-secondary";
    default:
      return "text-gray-500";
  }
}

export function getLevelBadgeColor(level: number): string {
  switch (level) {
    case 1:
      return "bg-gray-200";
    case 2:
      return "bg-accent";
    case 3:
      return "bg-primary";
    case 4:
      return "bg-secondary";
    default:
      return "bg-gray-200";
  }
}

export function getLevelName(level: number): string {
  switch (level) {
    case 1:
      return "เริ่มต้น";
    case 2:
      return "มาตรฐาน";
    case 3:
      return "พรีเมียม";
    case 4:
      return "วีไอพี";
    default:
      return "เริ่มต้น";
  }
}

export async function registerUser(userData: any) {
  try {
    const response = await apiRequest("POST", "/api/users", userData);
    return await response.json();
  } catch (error) {
    console.error("Error registering user:", error);
    throw error;
  }
}

export async function getUserProfile(uid: string) {
  try {
    const response = await apiRequest("GET", `/api/users/profile?uid=${uid}`);
    return await response.json();
  } catch (error) {
    console.error("Error fetching user profile:", error);
    throw error;
  }
}

export interface InterestRates {
  level1: number;
  level2: number;
  level3: number;
  level4: number;
}

export async function getInterestRates(): Promise<InterestRates> {
  try {
    const response = await apiRequest("GET", "/api/settings");
    const settings = await response.json();
    
    const findValue = (key: string) => {
      const setting = settings.find((s: any) => s.key === key);
      return setting ? parseFloat(setting.value) : 0;
    };
    
    return {
      level1: findValue("interestRateLevel1"),
      level2: findValue("interestRateLevel2"),
      level3: findValue("interestRateLevel3"),
      level4: findValue("interestRateLevel4")
    };
  } catch (error) {
    console.error("Error fetching interest rates:", error);
    return { level1: 5, level2: 3, level3: 2, level4: 1 };
  }
}

export function getInterestRateByLevel(rates: InterestRates, level: number): number {
  switch (level) {
    case 1:
      return rates.level1;
    case 2:
      return rates.level2;
    case 3:
      return rates.level3;
    case 4:
      return rates.level4;
    default:
      return rates.level1;
  }
}
