import React from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import LoanRequestForm from "@/components/loan/LoanRequestForm";
import ActiveLoan from "@/components/loan/ActiveLoan";
import { formatCurrency, formatDate } from "@/lib/utils";

const Loans: React.FC = () => {
  const { userProfile } = useAuth();

  // Fetch user's loans
  const { data: loans = [], isLoading: loansLoading } = useQuery({
    queryKey: [`/api/users/${userProfile?.id}/loans`],
    queryFn: async () => {
      const response = await fetch(`/api/users/${userProfile?.id}/loans`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch loans");
      return response.json();
    },
    enabled: !!userProfile?.id
  });

  // Find active loan
  const activeLoan = loans.find(loan => loan.status === "active");
  
  // Get completed loans for loan history
  const completedLoans = loans.filter(loan => loan.status === "completed");

  if (!userProfile) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left column - Loan management */}
      <div className="lg:col-span-8">
        <div className="bg-white rounded-lg shadow p-5">
          <h2 className="text-xl font-bold mb-6">จัดการเงินกู้ของคุณ</h2>
          
          {/* Loan request form */}
          <LoanRequestForm />
          
          {/* Active loan */}
          <div>
            <h3 className="text-lg font-semibold mb-4">เงินกู้ที่กำลังผ่อนชำระ</h3>
            {loansLoading ? (
              <div className="flex justify-center items-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : activeLoan ? (
              <ActiveLoan loan={activeLoan} />
            ) : (
              <div className="border rounded-lg p-4 text-center">
                <p className="text-gray-500">คุณยังไม่มีเงินกู้ที่กำลังผ่อนชำระอยู่</p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Right column - Loan history */}
      <div className="lg:col-span-4">
        <div className="bg-white rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold mb-4">ประวัติการกู้เงิน</h2>
          {loansLoading ? (
            <div className="flex justify-center items-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : completedLoans.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-gray-500">ยังไม่มีประวัติการกู้เงิน</p>
            </div>
          ) : (
            <div className="space-y-4">
              {completedLoans.map(loan => (
                <div key={loan.id} className="border-b pb-4">
                  <div className="flex justify-between">
                    <div>
                      <div className="font-medium">เงินกู้ #{loan.id}</div>
                      <div className="text-sm text-gray-500">
                        {formatDate(loan.createdAt)} - {loan.nextPaymentDate ? formatDate(loan.nextPaymentDate) : 'N/A'}
                      </div>
                    </div>
                    <span className="bg-secondary/10 text-secondary px-2 py-1 rounded text-sm font-medium">ชำระแล้ว</span>
                  </div>
                  <div className="flex justify-between mt-2">
                    <span className="text-sm text-gray-500">จำนวนเงิน</span>
                    <span className="font-medium">{formatCurrency(loan.amount)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {/* Level history */}
          <div className="mt-6">
            <h3 className="text-md font-semibold mb-3">ประวัติระดับสมาชิก</h3>
            <div className="relative">
              <div className="absolute left-2.5 top-0 bottom-0 w-0.5 bg-gray-200"></div>
              <div className="space-y-4 relative">
                {userProfile.level >= 3 && (
                  <div className="flex items-start">
                    <div className="w-5 h-5 rounded-full bg-primary mt-1 mr-3 z-10"></div>
                    <div>
                      <div className="font-medium">เลื่อนขั้นเป็น Level 3</div>
                      <div className="text-sm text-gray-500">5 มี.ค. 2566</div>
                      <div className="text-sm text-gray-600 mt-1">คืนเงินตรงเวลาครบ 5 ครั้ง</div>
                    </div>
                  </div>
                )}
                
                {userProfile.level >= 2 && (
                  <div className="flex items-start">
                    <div className="w-5 h-5 rounded-full bg-gray-300 mt-1 mr-3 z-10"></div>
                    <div>
                      <div className="font-medium">เลื่อนขั้นเป็น Level 2</div>
                      <div className="text-sm text-gray-500">15 ธ.ค. 2565</div>
                      <div className="text-sm text-gray-600 mt-1">คืนเงินตรงเวลาครบ 2 ครั้ง</div>
                    </div>
                  </div>
                )}
                
                <div className="flex items-start">
                  <div className="w-5 h-5 rounded-full bg-gray-300 mt-1 mr-3 z-10"></div>
                  <div>
                    <div className="font-medium">เริ่มต้นเป็น Level 1</div>
                    <div className="text-sm text-gray-500">1 ก.ย. 2565</div>
                    <div className="text-sm text-gray-600 mt-1">สมัครสมาชิกสำเร็จ</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Loans;
