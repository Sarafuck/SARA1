import React from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import CreatePost from "@/components/post/CreatePost";
import PostCard from "@/components/post/PostCard";
import UserLevelCard from "@/components/user/UserLevelCard";
import LoanSummaryCard from "@/components/loan/LoanSummaryCard";
import { Link } from "wouter";
import { getInterestRateByLevel, getInterestRates } from "@/lib/utils";

const Dashboard: React.FC = () => {
  const { userProfile } = useAuth();

  // Fetch all posts
  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: ["/api/posts"],
    queryFn: async () => {
      const response = await fetch("/api/posts", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    }
  });

  // Fetch all users for post author info
  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch users");
      return response.json();
    },
    enabled: posts.length > 0
  });

  // Fetch user's active loans
  const { data: loans = [], isLoading: loansLoading } = useQuery({
    queryKey: [`/api/users/${userProfile?.id}/loans`],
    queryFn: async () => {
      const response = await fetch(`/api/users/${userProfile?.id}/loans`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch loans");
      return response.json();
    },
    enabled: !!userProfile?.id
  });

  // Fetch interest rates
  const { data: interestRates } = useQuery({
    queryKey: ["/api/settings/interest-rates"],
    queryFn: async () => {
      return getInterestRates();
    }
  });

  // Find current active loan
  const activeLoan = loans.find(loan => loan.status === "active");

  // Calculate available amount for loans
  const calculateAvailableAmount = () => {
    if (!userProfile) return 0;
    
    const maxAmount = 10000 * userProfile.level; // Base amount * level
    
    // If there's an active loan, subtract it from max amount
    const usedAmount = activeLoan?.amount || 0;
    return Math.max(0, maxAmount - usedAmount);
  };

  // Get interest rate for user's level
  const userInterestRate = userProfile && interestRates
    ? getInterestRateByLevel(interestRates, userProfile.level)
    : 5;

  // Map post author info
  const postsWithAuthorInfo = posts.map(post => {
    const author = users.find(user => user.id === post.userId);
    return { ...post, author };
  });

  if (!userProfile) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left column - Feed */}
      <div className="lg:col-span-8">
        {/* Create post */}
        <CreatePost />

        {/* Posts feed */}
        {postsLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : posts.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-6 text-center">
            <p className="text-gray-500">ยังไม่มีโพสต์ในขณะนี้ เริ่มต้นสร้างโพสต์แรกของคุณ!</p>
          </div>
        ) : (
          postsWithAuthorInfo.map(post => (
            <PostCard 
              key={post.id} 
              post={post} 
              userData={post.author} 
            />
          ))
        )}
      </div>
      
      {/* Right column - Financial Summary */}
      <div className="lg:col-span-4 space-y-6">
        {/* User level card */}
        <UserLevelCard user={userProfile} interestRate={userInterestRate} />
        
        {/* Loan summary card */}
        <LoanSummaryCard 
          availableAmount={calculateAvailableAmount()} 
          maxAmount={10000 * userProfile.level}
          currentLoan={activeLoan}
        />
        
        {/* Fraud check promo */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-2">ตรวจสอบความปลอดภัย</h2>
          <p className="text-sm text-gray-600 mb-3">
            ตรวจสอบบัญชีและเบอร์โทรศัพท์ก่อนทำธุรกรรมเพื่อความปลอดภัย
          </p>
          <Link href="/fraud-check" className="inline-block w-full bg-gray-100 hover:bg-gray-200 text-center py-2 rounded-lg text-gray-700 font-medium">
            ตรวจสอบเลย
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
