import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { signIn } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { getUserProfile } from "@/lib/utils";

const Login: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validate input
      if (!email || !password) {
        toast({
          title: "กรุณากรอกข้อมูลให้ครบถ้วน",
          description: "โปรดระบุอีเมลและรหัสผ่าน",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Attempt to sign in
      const result = await signIn(email, password);

      if (result.error) {
        toast({
          title: "เข้าสู่ระบบไม่สำเร็จ",
          description: result.error,
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // Fetch user profile from API
      if (result.user) {
        try {
          await getUserProfile(result.user.uid);
          navigate("/");
        } catch (profileError: any) {
          // If user exists in Firebase but not in our database, redirect to registration
          if (profileError.message.includes("User not found")) {
            navigate("/register", { state: { email } });
          } else {
            toast({
              title: "เกิดข้อผิดพลาด",
              description: "ไม่สามารถดึงข้อมูลผู้ใช้ได้",
              variant: "destructive",
            });
          }
        }
      }
    } catch (error: any) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Admin quick login for demo
  const handleAdminLogin = async () => {
    setEmail("admin@example.com");
    setPassword("password123");
    // Submit the form
    setTimeout(() => {
      const form = document.querySelector("form");
      if (form) form.dispatchEvent(new Event("submit", { cancelable: true }));
    }, 100);
  };
  
  // Test user login for demo
  const handleTestLogin = async () => {
    setEmail("test@socialloan.co.th");
    setPassword("test1234");
    // Submit the form
    setTimeout(() => {
      const form = document.querySelector("form");
      if (form) form.dispatchEvent(new Event("submit", { cancelable: true }));
    }, 100);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-light px-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-primary mb-2">SocialLoan</h1>
            <p className="text-gray-600">เข้าสู่ระบบเพื่อใช้งาน</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                อีเมล
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                placeholder="your.email@example.com"
              />
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  รหัสผ่าน
                </label>
                <a href="#" className="text-sm text-primary hover:underline">
                  ลืมรหัสผ่าน?
                </a>
              </div>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                placeholder="••••••••"
              />
            </div>
            
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-primary/90 disabled:opacity-50"
            >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  กำลังเข้าสู่ระบบ...
                </span>
              ) : (
                "เข้าสู่ระบบ"
              )}
            </button>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              ยังไม่มีบัญชี?{" "}
              <Link href="/register" className="text-primary font-medium hover:underline">
                สมัครสมาชิก
              </Link>
            </p>
          </div>

          {/* Quick login options for demo */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-sm text-gray-500 mb-2 text-center">สำหรับการทดลองใช้</p>
            <div className="space-y-2">
              <button
                onClick={handleTestLogin}
                className="w-full bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200"
              >
                เข้าสู่ระบบด้วยบัญชีทดสอบ
              </button>
              <button
                onClick={handleAdminLogin}
                className="w-full bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200"
              >
                เข้าสู่ระบบด้วยบัญชี Admin
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
