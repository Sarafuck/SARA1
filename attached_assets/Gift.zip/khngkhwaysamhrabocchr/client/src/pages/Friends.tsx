import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import FriendItem from "@/components/friend/FriendItem";
import { getInitials, getLevelBadgeColor } from "@/lib/utils";

const Friends: React.FC = () => {
  const { userProfile } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch user's friends
  const { data: friends = [], isLoading: friendsLoading } = useQuery({
    queryKey: [`/api/users/${userProfile?.id}/friends`],
    queryFn: async () => {
      const response = await fetch(`/api/users/${userProfile?.id}/friends`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch friends");
      return response.json();
    },
    enabled: !!userProfile?.id
  });

  // Fetch friend requests
  const { data: friendRequests = [], isLoading: requestsLoading } = useQuery({
    queryKey: [`/api/users/${userProfile?.id}/friend-requests`],
    queryFn: async () => {
      const response = await fetch(`/api/users/${userProfile?.id}/friend-requests`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch friend requests");
      return response.json();
    },
    enabled: !!userProfile?.id
  });

  // Fetch all users for friend suggestions
  const { data: allUsers = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch users");
      return response.json();
    }
  });

  // Filter friends based on search query
  const filteredFriends = searchQuery 
    ? friends.filter(friend => 
        friend.fullName?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : friends;

  // Generate friend suggestions (users who are not friends and haven't sent/received requests)
  const friendSuggestions = allUsers.filter(user => {
    // Skip if it's the current user
    if (user.id === userProfile?.id) return false;
    
    // Skip if already friends
    const isFriend = friends.some(friend => 
      friend.userId === user.id || friend.friendId === user.id
    );
    if (isFriend) return false;
    
    // Skip if there's a pending request
    const hasPendingRequest = friendRequests.some(request => 
      request.userId === user.id || request.friendId === user.id
    );
    
    return !hasPendingRequest;
  }).slice(0, 5); // Limit to 5 suggestions

  if (!userProfile) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left - Friends list */}
      <div className="lg:col-span-8">
        <div className="bg-white rounded-lg shadow p-5">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-xl font-bold">เพื่อนของคุณ</h2>
            <div className="relative">
              <input 
                type="text" 
                placeholder="ค้นหาเพื่อน..." 
                className="pl-8 border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:outline-none"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>
          
          {friendsLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredFriends.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">คุณยังไม่มีเพื่อน</p>
              <p className="text-sm text-gray-400">
                เริ่มต้นเพิ่มเพื่อนจากคำแนะนำด้านขวา
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredFriends.map(friend => (
                <FriendItem key={friend.id} friend={friend} />
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Right - Friend suggestions and requests */}
      <div className="lg:col-span-4 space-y-6">
        {/* Friend requests */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-3">คำขอเป็นเพื่อน</h2>
          
          {requestsLoading ? (
            <div className="flex justify-center items-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : friendRequests.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-gray-500">ไม่มีคำขอเป็นเพื่อนในขณะนี้</p>
            </div>
          ) : (
            <div className="space-y-3">
              {friendRequests.map(request => (
                <div key={request.id} className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 text-sm font-medium overflow-hidden mr-3">
                    <span>{getInitials(request.fullName || "")}</span>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{request.fullName || "User"}</div>
                    <div className="text-xs text-gray-500">2 เพื่อนร่วมกัน</div>
                  </div>
                  <div className="flex space-x-2">
                    <button 
                      className="bg-primary text-white px-3 py-1 rounded text-sm"
                      onClick={() => console.log("Accept friend request", request.id)}
                    >
                      ยอมรับ
                    </button>
                    <button 
                      className="bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm"
                      onClick={() => console.log("Reject friend request", request.id)}
                    >
                      ปฏิเสธ
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Friend suggestions */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-3">เพื่อนที่คุณอาจรู้จัก</h2>
          
          {usersLoading ? (
            <div className="flex justify-center items-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : friendSuggestions.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-gray-500">ไม่มีคำแนะนำเพื่อนในขณะนี้</p>
            </div>
          ) : (
            <div className="space-y-4">
              {friendSuggestions.map(user => (
                <div key={user.id} className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 text-sm font-medium overflow-hidden mr-3">
                    <span>{getInitials(user.fullName)}</span>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{user.fullName}</div>
                    <div className="flex items-center text-xs text-gray-500">
                      <span>Level {user.level}</span>
                      <div className={`w-2 h-2 rounded-full ${getLevelBadgeColor(user.level)} ml-1 mr-2`}></div>
                      <span>เพื่อนร่วมกัน</span>
                    </div>
                  </div>
                  <button 
                    className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm"
                    onClick={() => console.log("Add friend", user.id)}
                  >
                    <i className="fas fa-user-plus mr-1"></i> เพิ่ม
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Friends;
