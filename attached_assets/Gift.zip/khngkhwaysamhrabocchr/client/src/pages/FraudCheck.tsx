import React, { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";

const FraudCheck: React.FC = () => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  
  // Form states
  const [searchType, setSearchType] = useState("phone");
  const [searchValue, setSearchValue] = useState("");
  const [showResults, setShowResults] = useState(false);
  
  // Report form states
  const [reportType, setReportType] = useState("phone");
  const [reportPhone, setReportPhone] = useState("");
  const [reportAccount, setReportAccount] = useState("");
  const [reportName, setReportName] = useState("");
  const [reportIssueType, setReportIssueType] = useState("");
  const [reportDetails, setReportDetails] = useState("");
  
  // Search for fraud reports
  const { data: searchResults = [], isLoading: searchLoading, refetch } = useQuery({
    queryKey: [`/api/fraud-reports/search`, searchType, searchValue],
    queryFn: async () => {
      if (!searchValue) return [];
      
      const response = await fetch(`/api/fraud-reports/search?type=${searchType}&value=${encodeURIComponent(searchValue)}`, {
        credentials: "include",
      });
      
      if (!response.ok) throw new Error("Failed to search for fraud reports");
      return response.json();
    },
    enabled: false, // Only run when manually triggered
  });
  
  // Submit search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchValue.trim()) {
      toast({
        title: "กรุณาระบุข้อมูลที่ต้องการค้นหา",
        variant: "destructive",
      });
      return;
    }
    
    setShowResults(true);
    refetch();
  };
  
  // Submit report
  const reportMutation = useMutation({
    mutationFn: async () => {
      if (!userProfile?.id) {
        throw new Error("You must be logged in to submit a report");
      }
      
      // Validate form
      if (reportType === "phone" && !reportPhone) {
        throw new Error("กรุณาระบุเบอร์โทรศัพท์");
      }
      
      if (reportType === "account" && !reportAccount) {
        throw new Error("กรุณาระบุเลขที่บัญชี");
      }
      
      if (reportType === "both" && (!reportPhone || !reportAccount)) {
        throw new Error("กรุณาระบุทั้งเบอร์โทรศัพท์และเลขที่บัญชี");
      }
      
      if (!reportIssueType) {
        throw new Error("กรุณาเลือกประเภทของปัญหา");
      }
      
      return apiRequest("POST", "/api/fraud-reports", {
        reporterId: userProfile.id,
        fullName: reportName,
        phoneNumber: reportPhone,
        bankAccount: reportAccount,
        reportType: reportIssueType,
        details: reportDetails,
      });
    },
    onSuccess: () => {
      toast({
        title: "ส่งรายงานสำเร็จ",
        description: "ขอบคุณสำหรับการรายงาน เราจะตรวจสอบข้อมูลที่คุณให้มาโดยเร็วที่สุด",
      });
      
      // Reset form
      setReportType("phone");
      setReportPhone("");
      setReportAccount("");
      setReportName("");
      setReportIssueType("");
      setReportDetails("");
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    reportMutation.mutate();
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h1 className="text-2xl font-bold mb-6">ตรวจสอบบัญชี</h1>
      
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start">
          <div className="text-blue-500 mr-3">
            <i className="fas fa-info-circle text-xl"></i>
          </div>
          <div>
            <h3 className="font-medium text-blue-700">ช่วยกันป้องกันการโกง</h3>
            <p className="text-sm text-blue-600 mt-1">
              ตรวจสอบเบอร์โทรหรือเลขที่บัญชีก่อนทำธุรกรรม เพื่อลดความเสี่ยงจากมิจฉาชีพ ข้อมูลที่แสดงมาจากระบบและการรายงานของผู้ใช้อื่น
            </p>
          </div>
        </div>
      </div>
      
      {/* Search form */}
      <div className="mb-8">
        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-3">
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                <div className="flex-1">
                  <select 
                    className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                    value={searchType}
                    onChange={(e) => setSearchType(e.target.value)}
                  >
                    <option value="phone">เบอร์โทรศัพท์</option>
                    <option value="account">เลขที่บัญชี</option>
                    <option value="name">ชื่อ-นามสกุล</option>
                  </select>
                </div>
                <div className="flex-1">
                  <input 
                    type="text" 
                    placeholder="กรอกข้อมูลที่ต้องการตรวจสอบ" 
                    className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                  />
                </div>
              </div>
            </div>
            <div className="md:col-span-1">
              <button 
                type="submit"
                className="w-full bg-primary text-white py-2.5 rounded-lg font-medium hover:bg-primary/90"
                disabled={searchLoading}
              >
                {searchLoading ? (
                  <span className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    กำลังค้นหา...
                  </span>
                ) : (
                  <>
                    <i className="fas fa-search mr-1"></i> ค้นหา
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
      
      {/* Result section */}
      <div className="border rounded-lg overflow-hidden">
        <div className="bg-gray-50 p-4 border-b">
          <h2 className="font-semibold">ผลการตรวจสอบ</h2>
        </div>
        
        {/* Result content */}
        {!showResults ? (
          <div className="p-4">
            <div className="flex items-center justify-center h-48 text-center text-gray-500">
              <div>
                <i className="fas fa-search text-3xl mb-2"></i>
                <p>กรุณากรอกข้อมูลเพื่อค้นหา</p>
              </div>
            </div>
          </div>
        ) : searchLoading ? (
          <div className="p-4">
            <div className="flex justify-center items-center h-48">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          </div>
        ) : searchResults.length === 0 ? (
          <div className="p-6">
            <div className="text-center mb-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-500 mb-3">
                <i className="fas fa-check-circle text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-green-600">ไม่พบข้อมูลในรายการเฝ้าระวัง</h3>
              <p className="text-gray-600 mt-1">
                ข้อมูลที่คุณค้นหายังไม่เคยมีการรายงานปัญหาในระบบ
              </p>
            </div>
          </div>
        ) : (
          <div className="p-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-danger/10 text-danger mb-3">
                <i className="fas fa-exclamation-triangle text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-danger">พบข้อมูลในรายการเฝ้าระวัง</h3>
              <p className="text-gray-600 mt-1">บัญชีนี้มีประวัติการรายงานจากผู้ใช้{searchResults.length > 1 ? 'หลายราย' : '1 ราย'}</p>
            </div>
            
            <div className="max-w-2xl mx-auto">
              <div className="border rounded-lg overflow-hidden mb-6">
                <div className="bg-gray-50 p-3 border-b">
                  <h4 className="font-medium">ข้อมูลที่ตรวจพบ</h4>
                </div>
                <div className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {searchResults[0].phoneNumber && (
                      <div>
                        <div className="text-sm text-gray-500">เบอร์โทรศัพท์</div>
                        <div className="font-medium">{searchResults[0].phoneNumber}</div>
                      </div>
                    )}
                    {searchResults[0].bankAccount && (
                      <div>
                        <div className="text-sm text-gray-500">เลขที่บัญชี</div>
                        <div className="font-medium">{searchResults[0].bankAccount}</div>
                      </div>
                    )}
                    {searchResults[0].fullName && (
                      <div>
                        <div className="text-sm text-gray-500">ชื่อที่รายงาน</div>
                        <div className="font-medium">{searchResults[0].fullName}</div>
                      </div>
                    )}
                    <div>
                      <div className="text-sm text-gray-500">จำนวนรายงาน</div>
                      <div className="font-medium">{searchResults.length} ครั้ง</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg overflow-hidden mb-6">
                <div className="bg-gray-50 p-3 border-b">
                  <h4 className="font-medium">รายละเอียดการรายงาน</h4>
                </div>
                <div className="divide-y">
                  {searchResults.map((report, index) => (
                    <div key={report.id || index} className="p-4">
                      <div className="flex justify-between mb-2">
                        <div className="font-medium">
                          {report.reportType === "not_pay" && "ยืมเงินแล้วไม่คืน"}
                          {report.reportType === "late" && "โอนเงินช้า ไม่ตรงเวลา"}
                          {report.reportType === "scam" && "หลอกลวง"}
                          {report.reportType === "other" && "ปัญหาอื่นๆ"}
                        </div>
                        <div className="text-sm text-gray-500">{report.createdAt ? formatDate(report.createdAt) : ''}</div>
                      </div>
                      <p className="text-sm text-gray-600">{report.details}</p>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-center">
                <button className="bg-danger text-white px-4 py-2 rounded-lg font-medium hover:bg-danger/90 mr-3">
                  <i className="fas fa-flag mr-1"></i> รายงานเพิ่มเติม
                </button>
                <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200">
                  <i className="fas fa-share-alt mr-1"></i> แชร์ข้อมูล
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Report form */}
      <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">รายงานบัญชีที่น่าสงสัย</h2>
        <div className="bg-white border rounded-lg p-6">
          <div className="max-w-2xl mx-auto">
            <form className="space-y-4" onSubmit={handleSubmitReport}>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ประเภทข้อมูล</label>
                <select 
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                  value={reportType}
                  onChange={(e) => setReportType(e.target.value)}
                >
                  <option value="phone">เบอร์โทรศัพท์</option>
                  <option value="account">เลขที่บัญชี</option>
                  <option value="both">ทั้งเบอร์โทรและบัญชี</option>
                </select>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">เบอร์โทรศัพท์</label>
                  <input 
                    type="text" 
                    placeholder="0XX-XXX-XXXX" 
                    className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                    value={reportPhone}
                    onChange={(e) => setReportPhone(e.target.value)}
                    disabled={reportType === "account"}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">เลขที่บัญชี</label>
                  <input 
                    type="text" 
                    placeholder="XXX-X-XXXXX-X" 
                    className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                    value={reportAccount}
                    onChange={(e) => setReportAccount(e.target.value)}
                    disabled={reportType === "phone"}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ชื่อที่ใช้ (ถ้าทราบ)</label>
                <input 
                  type="text" 
                  placeholder="ชื่อ-นามสกุล หรือชื่อที่ใช้" 
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                  value={reportName}
                  onChange={(e) => setReportName(e.target.value)}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ประเภทของปัญหา</label>
                <select 
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                  value={reportIssueType}
                  onChange={(e) => setReportIssueType(e.target.value)}
                >
                  <option value="">-- เลือกประเภทปัญหา --</option>
                  <option value="not_pay">ยืมเงินแล้วไม่คืน</option>
                  <option value="late">คืนเงินช้า/ไม่ตรงเวลา</option>
                  <option value="scam">หลอกลวง</option>
                  <option value="other">อื่นๆ</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">รายละเอียดเพิ่มเติม</label>
                <textarea 
                  rows={4} 
                  placeholder="อธิบายรายละเอียดของปัญหาที่เกิดขึ้น..."
                  className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-primary focus:outline-none"
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                ></textarea>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">หลักฐาน (ถ้ามี)</label>
                <div className="border border-dashed border-gray-300 rounded-lg p-4 text-center">
                  <i className="fas fa-cloud-upload-alt text-gray-400 text-2xl mb-2"></i>
                  <p className="text-sm text-gray-500">ลากไฟล์มาวางที่นี่ หรือ <span className="text-primary font-medium">คลิกเพื่อเลือกไฟล์</span></p>
                  <p className="text-xs text-gray-500 mt-1">รองรับไฟล์ JPG, PNG, PDF ขนาดไม่เกิน 5MB</p>
                </div>
              </div>
              
              <div className="pt-2">
                <button 
                  type="submit"
                  className="bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-primary/90"
                  disabled={reportMutation.isPending}
                >
                  {reportMutation.isPending ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      กำลังส่งรายงาน...
                    </span>
                  ) : (
                    <>
                      <i className="fas fa-paper-plane mr-1"></i> ส่งรายงาน
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FraudCheck;
