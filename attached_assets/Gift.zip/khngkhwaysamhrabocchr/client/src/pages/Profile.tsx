import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { getInitials, formatDate, getLevelName, getLevelBadgeColor } from "@/lib/utils";
import CreatePost from "@/components/post/CreatePost";
import PostCard from "@/components/post/PostCard";

const Profile: React.FC = () => {
  const { userProfile } = useAuth();
  const [activeTab, setActiveTab] = useState("personal");

  // Fetch user's posts
  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: [`/api/users/${userProfile?.id}/posts`],
    queryFn: async () => {
      if (!userProfile?.id) throw new Error("User ID is required");
      
      const response = await fetch(`/api/users/${userProfile.id}/posts`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch posts");
      return response.json();
    },
    enabled: !!userProfile?.id
  });

  if (!userProfile) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <div className="bg-white rounded-lg shadow">
        {/* Cover image */}
        <div className="h-48 rounded-t-lg bg-primary/20 relative">
          <div className="absolute bottom-4 left-4 md:left-6 flex items-end">
            <div className="w-24 h-24 rounded-full border-4 border-white bg-primary text-white flex items-center justify-center text-3xl font-bold">
              <span>{getInitials(userProfile.fullName)}</span>
            </div>
            <div className="ml-4 text-dark">
              <h1 className="text-2xl font-bold">{userProfile.fullName}</h1>
              <div className="flex items-center">
                <span className="bg-primary/10 text-primary px-2 py-0.5 rounded text-sm font-medium">
                  Level {userProfile.level}
                </span>
                <span className="text-sm text-gray-600 ml-2">
                  สมาชิกตั้งแต่ {formatDate(userProfile.createdAt)}
                </span>
              </div>
            </div>
          </div>
          <button className="absolute bottom-4 right-4 bg-white text-gray-700 px-3 py-1 rounded-lg text-sm shadow">
            <i className="fas fa-camera mr-1"></i> เปลี่ยนภาพ
          </button>
        </div>
        
        {/* Profile navigation */}
        <div className="px-4 pt-16 md:pt-4 pb-1 border-b">
          <div className="flex space-x-6">
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "personal" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => setActiveTab("personal")}
            >
              ข้อมูลส่วนตัว
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "activity" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => setActiveTab("activity")}
            >
              กิจกรรม
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "friends" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => setActiveTab("friends")}
            >
              เพื่อน
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "financial" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => setActiveTab("financial")}
            >
              ประวัติการเงิน
            </button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
        {/* Left column - Profile info */}
        <div className="lg:col-span-4 space-y-6">
          {/* About section */}
          <div className="bg-white rounded-lg shadow p-4">
            <h2 className="text-lg font-semibold mb-4">ข้อมูลส่วนตัว</h2>
            <div className="space-y-3">
              <div>
                <div className="text-sm text-gray-500">ชื่อ-นามสกุล</div>
                <div className="font-medium">{userProfile.fullName}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">เบอร์โทรศัพท์</div>
                <div className="font-medium">{userProfile.phoneNumber}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">อีเมล</div>
                <div className="font-medium">{userProfile.email}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">บัญชีธนาคาร</div>
                <div className="font-medium">{userProfile.bankAccount}</div>
              </div>
            </div>
            <button className="mt-4 w-full border border-primary text-primary py-2 rounded-lg font-medium hover:bg-primary/5">
              แก้ไขข้อมูล
            </button>
          </div>
          
          {/* Level & XP section */}
          <div className="bg-white rounded-lg shadow p-4">
            <h2 className="text-lg font-semibold mb-4">ระดับและ XP</h2>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <div className={`w-12 h-12 rounded-full ${getLevelBadgeColor(userProfile.level)} flex items-center justify-center text-white font-bold text-xl`}>
                  <span>{userProfile.level}</span>
                </div>
                <div className="ml-3">
                  <div className="font-medium">ระดับ {getLevelName(userProfile.level)}</div>
                  <div className="text-sm text-gray-500">คืนเงินตรงเวลา {userProfile.onTimeRepayments} ครั้ง</div>
                </div>
              </div>
            </div>
            
            {/* Level progress */}
            {userProfile.level < 4 && (
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-1">
                  <div>ความก้าวหน้า</div>
                  <div>
                    {userProfile.level === 1 && `${userProfile.onTimeRepayments}/2 ครั้ง`}
                    {userProfile.level === 2 && `${userProfile.onTimeRepayments}/5 ครั้ง`}
                    {userProfile.level === 3 && `${userProfile.onTimeRepayments}/15 ครั้ง`}
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-primary h-2.5 rounded-full" 
                    style={{ 
                      width: userProfile.level === 1 
                        ? `${Math.min(100, (userProfile.onTimeRepayments / 2) * 100)}%`
                        : userProfile.level === 2
                        ? `${Math.min(100, (userProfile.onTimeRepayments / 5) * 100)}%`
                        : `${Math.min(100, (userProfile.onTimeRepayments / 15) * 100)}%`
                    }}
                  ></div>
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {userProfile.level === 1 && `อีก ${Math.max(0, 2 - userProfile.onTimeRepayments)} ครั้งเพื่อขึ้นเป็น Level 2`}
                  {userProfile.level === 2 && `อีก ${Math.max(0, 5 - userProfile.onTimeRepayments)} ครั้งเพื่อขึ้นเป็น Level 3`}
                  {userProfile.level === 3 && `อีก ${Math.max(0, 15 - userProfile.onTimeRepayments)} ครั้งเพื่อขึ้นเป็น Level 4`}
                </div>
              </div>
            )}
            
            {/* XP status */}
            <div className="mt-6">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium">XP ทั้งหมด</span>
                <span className="text-primary font-semibold">{userProfile.xp} XP</span>
              </div>
              <div className="text-xs text-gray-500">XP คือคะแนนที่คุณได้จากกิจกรรมต่างๆ บนแพลตฟอร์ม</div>
              
              <h3 className="text-sm font-medium mt-3 mb-2">กิจกรรมล่าสุดที่ได้รับ XP</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span>คืนเงินตรงเวลา</span>
                  <span className="text-secondary">+30 XP</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>โพสต์ได้รับไลค์</span>
                  <span className="text-secondary">+5 XP</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>แสดงความคิดเห็น</span>
                  <span className="text-secondary">+2 XP</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Right column - User posts and activity */}
        <div className="lg:col-span-8">
          {/* Create post */}
          <CreatePost />
          
          {/* User's posts */}
          {postsLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : posts.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <p className="text-gray-500">คุณยังไม่มีโพสต์ เริ่มต้นแชร์สิ่งที่คุณคิดกันเถอะ!</p>
            </div>
          ) : (
            <div className="space-y-6">
              {posts.map(post => (
                <PostCard 
                  key={post.id} 
                  post={post}
                  userData={userProfile}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Profile;
