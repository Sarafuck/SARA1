import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const Admin: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  
  // Form states for system settings
  const [interestLevel1, setInterestLevel1] = useState(5);
  const [interestLevel2, setInterestLevel2] = useState(3);
  const [interestLevel3, setInterestLevel3] = useState(2);
  const [interestLevel4, setInterestLevel4] = useState(1);
  const [registrationFee, setRegistrationFee] = useState(100);
  const [levelUpThreshold2, setLevelUpThreshold2] = useState(2);
  const [levelUpThreshold3, setLevelUpThreshold3] = useState(5);
  const [levelUpThreshold4, setLevelUpThreshold4] = useState(15);
  const [xpOnTimePayment, setXpOnTimePayment] = useState(30);
  const [xpLatePayment, setXpLatePayment] = useState(-20);
  const [xpPostLike, setXpPostLike] = useState(1);
  const [xpPostDislike, setXpPostDislike] = useState(-5);
  const [xpGiveLike, setXpGiveLike] = useState(-1);
  const [xpGiveDislike, setXpGiveDislike] = useState(-2);
  
  // Fetch all system settings
  const { data: settings = [], isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      const response = await fetch("/api/settings", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch settings");
      return response.json();
    },
    onSuccess: (data) => {
      // Update form states with fetched settings
      data.forEach((setting: any) => {
        if (setting.key === "interestRateLevel1") setInterestLevel1(parseFloat(setting.value));
        if (setting.key === "interestRateLevel2") setInterestLevel2(parseFloat(setting.value));
        if (setting.key === "interestRateLevel3") setInterestLevel3(parseFloat(setting.value));
        if (setting.key === "interestRateLevel4") setInterestLevel4(parseFloat(setting.value));
        if (setting.key === "registrationFee") setRegistrationFee(parseInt(setting.value));
        if (setting.key === "levelUpThreshold2") setLevelUpThreshold2(parseInt(setting.value));
        if (setting.key === "levelUpThreshold3") setLevelUpThreshold3(parseInt(setting.value));
        if (setting.key === "levelUpThreshold4") setLevelUpThreshold4(parseInt(setting.value));
        if (setting.key === "xpOnTimePayment") setXpOnTimePayment(parseInt(setting.value));
        if (setting.key === "xpLatePayment") setXpLatePayment(parseInt(setting.value));
        if (setting.key === "xpPostLike") setXpPostLike(parseInt(setting.value));
        if (setting.key === "xpPostDislike") setXpPostDislike(parseInt(setting.value));
        if (setting.key === "xpGiveLike") setXpGiveLike(parseInt(setting.value));
        if (setting.key === "xpGiveDislike") setXpGiveDislike(parseInt(setting.value));
      });
    }
  });
  
  // Fetch stats for overview
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch users");
      return response.json();
    }
  });
  
  const { data: loans = [] } = useQuery({
    queryKey: ["/api/loans"],
    queryFn: async () => {
      const response = await fetch("/api/loans", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch loans");
      return response.json();
    }
  });
  
  const { data: fraudReports = [] } = useQuery({
    queryKey: ["/api/fraud-reports"],
    queryFn: async () => {
      const response = await fetch("/api/fraud-reports", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch fraud reports");
      return response.json();
    }
  });
  
  // Calculate stats
  const totalUsers = users.length;
  const totalLoanAmount = loans.reduce((sum: number, loan: any) => sum + loan.amount, 0);
  const totalInterest = loans.reduce((sum: number, loan: any) => {
    return sum + (loan.amount * loan.interestRate / 100);
  }, 0);
  const recentFraudReports = fraudReports.filter((report: any) => {
    const reportDate = new Date(report.createdAt);
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    return reportDate >= oneWeekAgo;
  }).length;
  
  // Update system settings
  const updateSettingMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string, value: string }) => {
      return apiRequest("PUT", `/api/settings/${key}`, { value });
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSaveSettings = async () => {
    try {
      // Update all settings
      await updateSettingMutation.mutateAsync({ key: "interestRateLevel1", value: interestLevel1.toString() });
      await updateSettingMutation.mutateAsync({ key: "interestRateLevel2", value: interestLevel2.toString() });
      await updateSettingMutation.mutateAsync({ key: "interestRateLevel3", value: interestLevel3.toString() });
      await updateSettingMutation.mutateAsync({ key: "interestRateLevel4", value: interestLevel4.toString() });
      await updateSettingMutation.mutateAsync({ key: "registrationFee", value: registrationFee.toString() });
      await updateSettingMutation.mutateAsync({ key: "levelUpThreshold2", value: levelUpThreshold2.toString() });
      await updateSettingMutation.mutateAsync({ key: "levelUpThreshold3", value: levelUpThreshold3.toString() });
      await updateSettingMutation.mutateAsync({ key: "levelUpThreshold4", value: levelUpThreshold4.toString() });
      await updateSettingMutation.mutateAsync({ key: "xpOnTimePayment", value: xpOnTimePayment.toString() });
      await updateSettingMutation.mutateAsync({ key: "xpLatePayment", value: xpLatePayment.toString() });
      await updateSettingMutation.mutateAsync({ key: "xpPostLike", value: xpPostLike.toString() });
      await updateSettingMutation.mutateAsync({ key: "xpPostDislike", value: xpPostDislike.toString() });
      await updateSettingMutation.mutateAsync({ key: "xpGiveLike", value: xpGiveLike.toString() });
      await updateSettingMutation.mutateAsync({ key: "xpGiveDislike", value: xpGiveDislike.toString() });
      
      // Refresh settings data
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      
      toast({
        title: "บันทึกการตั้งค่าสำเร็จ",
        description: "การตั้งค่าระบบได้รับการอัปเดตแล้ว",
      });
    } catch (error) {
      console.error("Failed to save settings:", error);
    }
  };

  return (
    <>
      <div className="bg-dark text-white rounded-lg shadow">
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-1">แผงควบคุมผู้ดูแลระบบ</h1>
          <p className="text-gray-400">จัดการระบบ Social Media & Lending</p>
        </div>
        
        {/* Admin navigation */}
        <div className="px-6 pb-1 border-b border-gray-700">
          <div className="flex space-x-6 overflow-x-auto">
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "overview" ? "text-primary border-b-2 border-primary" : "text-gray-400 hover:text-white"}`}
              onClick={() => setActiveTab("overview")}
            >
              ภาพรวม
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "users" ? "text-primary border-b-2 border-primary" : "text-gray-400 hover:text-white"}`}
              onClick={() => setActiveTab("users")}
            >
              จัดการสมาชิก
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "loans" ? "text-primary border-b-2 border-primary" : "text-gray-400 hover:text-white"}`}
              onClick={() => setActiveTab("loans")}
            >
              จัดการเงินกู้
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "posts" ? "text-primary border-b-2 border-primary" : "text-gray-400 hover:text-white"}`}
              onClick={() => setActiveTab("posts")}
            >
              โพสต์และกิจกรรม
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "reports" ? "text-primary border-b-2 border-primary" : "text-gray-400 hover:text-white"}`}
              onClick={() => setActiveTab("reports")}
            >
              รายงานบัญชีน่าสงสัย
            </button>
            <button 
              className={`px-3 py-2 font-medium ${activeTab === "settings" ? "text-primary border-b-2 border-primary" : "text-gray-400 hover:text-white"}`}
              onClick={() => setActiveTab("settings")}
            >
              ตั้งค่าระบบ
            </button>
          </div>
        </div>
      </div>
      
      {/* Main content based on active tab */}
      {activeTab === "overview" && (
        <div className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Stats cards */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-500">จำนวนสมาชิกทั้งหมด</div>
                  <div className="text-2xl font-bold">{totalUsers}</div>
                </div>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <i className="fas fa-users"></i>
                </div>
              </div>
              <div className="flex items-center mt-2 text-sm">
                <span className="text-secondary"><i className="fas fa-arrow-up mr-1"></i> 12%</span>
                <span className="text-gray-500 ml-2">จากเดือนที่แล้ว</span>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-500">ยอดเงินกู้ทั้งหมด</div>
                  <div className="text-2xl font-bold">{totalLoanAmount.toLocaleString()} ฿</div>
                </div>
                <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center text-secondary">
                  <i className="fas fa-money-bill-wave"></i>
                </div>
              </div>
              <div className="flex items-center mt-2 text-sm">
                <span className="text-secondary"><i className="fas fa-arrow-up mr-1"></i> 8%</span>
                <span className="text-gray-500 ml-2">จากเดือนที่แล้ว</span>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-500">ดอกเบี้ยรวม</div>
                  <div className="text-2xl font-bold">{totalInterest.toLocaleString()} ฿</div>
                </div>
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center text-accent">
                  <i className="fas fa-percentage"></i>
                </div>
              </div>
              <div className="flex items-center mt-2 text-sm">
                <span className="text-secondary"><i className="fas fa-arrow-up mr-1"></i> 5%</span>
                <span className="text-gray-500 ml-2">จากเดือนที่แล้ว</span>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-500">บัญชีที่ถูกรายงาน</div>
                  <div className="text-2xl font-bold">{fraudReports.length}</div>
                </div>
                <div className="w-12 h-12 rounded-full bg-danger/10 flex items-center justify-center text-danger">
                  <i className="fas fa-exclamation-triangle"></i>
                </div>
              </div>
              <div className="flex items-center mt-2 text-sm">
                <span className="text-danger"><i className="fas fa-arrow-up mr-1"></i> {recentFraudReports}</span>
                <span className="text-gray-500 ml-2">ในสัปดาห์นี้</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
            {/* Recent activity */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow h-full">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-bold">กิจกรรมล่าสุด</h2>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-3">
                        <i className="fas fa-user-plus"></i>
                      </div>
                      <div>
                        <div className="font-medium">สมัครสมาชิกใหม่ 5 คน</div>
                        <div className="text-sm text-gray-500">10 นาทีที่แล้ว</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center text-secondary mr-3">
                        <i className="fas fa-money-bill-wave"></i>
                      </div>
                      <div>
                        <div className="font-medium">การขอกู้ใหม่ 2 รายการ</div>
                        <div className="text-sm text-gray-500">30 นาทีที่แล้ว</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center text-secondary mr-3">
                        <i className="fas fa-check-circle"></i>
                      </div>
                      <div>
                        <div className="font-medium">ชำระเงินตรงเวลา 8 รายการ</div>
                        <div className="text-sm text-gray-500">1 ชั่วโมงที่แล้ว</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center text-accent mr-3">
                        <i className="fas fa-level-up-alt"></i>
                      </div>
                      <div>
                        <div className="font-medium">สมาชิกเลื่อนระดับ 3 คน</div>
                        <div className="text-sm text-gray-500">3 ชั่วโมงที่แล้ว</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center text-danger mr-3">
                        <i className="fas fa-exclamation-triangle"></i>
                      </div>
                      <div>
                        <div className="font-medium">มีการรายงานบัญชีใหม่ 1 รายการ</div>
                        <div className="text-sm text-gray-500">5 ชั่วโมงที่แล้ว</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 text-center">
                    <button className="text-primary font-medium hover:underline">
                      ดูทั้งหมด
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Quick settings overview */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-bold">ตั้งค่าพื้นฐานระบบ</h2>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">อัตราดอกเบี้ย</h3>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Level 1:</span>
                        <span>{interestLevel1}%</span>
                      </div>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Level 4:</span>
                        <span>{interestLevel4}%</span>
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">เกณฑ์การเลื่อนระดับ</h3>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Level 1 → 2:</span>
                        <span>{levelUpThreshold2} ครั้ง</span>
                      </div>
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Level 3 → 4:</span>
                        <span>{levelUpThreshold4} ครั้ง</span>
                      </div>
                    </div>
                  </div>
                  <button 
                    className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90"
                    onClick={() => setActiveTab("settings")}
                  >
                    ไปยังการตั้งค่าทั้งหมด
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {activeTab === "settings" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* System settings */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b">
                <h2 className="text-xl font-bold">ตั้งค่าระบบ</h2>
              </div>
              <div className="p-6">
                {settingsLoading ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Interest rate settings */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4">อัตราดอกเบี้ย</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Level 1 (เริ่มต้น)</label>
                          <div className="flex">
                            <input 
                              type="number" 
                              value={interestLevel1} 
                              min="0" 
                              max="100" 
                              step="0.1"
                              onChange={(e) => setInterestLevel1(parseFloat(e.target.value))}
                              className="w-full border border-gray-300 rounded-l-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                            <span className="bg-gray-100 flex items-center px-3 rounded-r-lg border border-l-0 border-gray-300">%</span>
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Level 2</label>
                          <div className="flex">
                            <input 
                              type="number" 
                              value={interestLevel2} 
                              min="0" 
                              max="100" 
                              step="0.1"
                              onChange={(e) => setInterestLevel2(parseFloat(e.target.value))}
                              className="w-full border border-gray-300 rounded-l-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                            <span className="bg-gray-100 flex items-center px-3 rounded-r-lg border border-l-0 border-gray-300">%</span>
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Level 3</label>
                          <div className="flex">
                            <input 
                              type="number" 
                              value={interestLevel3} 
                              min="0" 
                              max="100" 
                              step="0.1"
                              onChange={(e) => setInterestLevel3(parseFloat(e.target.value))}
                              className="w-full border border-gray-300 rounded-l-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                            <span className="bg-gray-100 flex items-center px-3 rounded-r-lg border border-l-0 border-gray-300">%</span>
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Level 4</label>
                          <div className="flex">
                            <input 
                              type="number" 
                              value={interestLevel4} 
                              min="0" 
                              max="100" 
                              step="0.1"
                              onChange={(e) => setInterestLevel4(parseFloat(e.target.value))}
                              className="w-full border border-gray-300 rounded-l-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                            <span className="bg-gray-100 flex items-center px-3 rounded-r-lg border border-l-0 border-gray-300">%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Membership fee */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4">ค่าสมัครสมาชิก</h3>
                      <div className="max-w-xs">
                        <label className="block text-sm font-medium text-gray-700 mb-1">ค่าธรรมเนียมแรกเข้า</label>
                        <div className="flex">
                          <span className="bg-gray-100 flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300">฿</span>
                          <input 
                            type="number" 
                            value={registrationFee} 
                            min="0" 
                            step="10"
                            onChange={(e) => setRegistrationFee(parseInt(e.target.value))}
                            className="w-full border border-gray-300 rounded-r-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                    
                    {/* Level thresholds */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4">เกณฑ์การเลื่อนระดับ</h3>
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <span className="w-24 text-sm">Level 1 → 2:</span>
                          <div className="flex items-center">
                            <input 
                              type="number" 
                              value={levelUpThreshold2} 
                              min="1"
                              onChange={(e) => setLevelUpThreshold2(parseInt(e.target.value))} 
                              className="w-16 border border-gray-300 rounded px-2 py-1 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                            <span className="ml-2 text-sm text-gray-600">ครั้งคืนตรงเวลา</span>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <span className="w-24 text-sm">Level 2 → 3:</span>
                          <div className="flex items-center">
                            <input 
                              type="number" 
                              value={levelUpThreshold3} 
                              min="1"
                              onChange={(e) => setLevelUpThreshold3(parseInt(e.target.value))} 
                              className="w-16 border border-gray-300 rounded px-2 py-1 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                            <span className="ml-2 text-sm text-gray-600">ครั้งคืนตรงเวลา</span>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <span className="w-24 text-sm">Level 3 → 4:</span>
                          <div className="flex items-center">
                            <input 
                              type="number" 
                              value={levelUpThreshold4} 
                              min="1"
                              onChange={(e) => setLevelUpThreshold4(parseInt(e.target.value))} 
                              className="w-16 border border-gray-300 rounded px-2 py-1 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                            <span className="ml-2 text-sm text-gray-600">ครั้งคืนตรงเวลา</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* XP settings */}
                    <div>
                      <h3 className="text-lg font-semibold mb-4">ตั้งค่า XP</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">คืนเงินตรงเวลา</label>
                          <div className="flex">
                            <span className="bg-gray-100 flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300">+</span>
                            <input 
                              type="number" 
                              value={xpOnTimePayment} 
                              min="0"
                              onChange={(e) => setXpOnTimePayment(parseInt(e.target.value))}
                              className="w-full border border-gray-300 rounded-r-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">คืนเงินล่าช้า</label>
                          <div className="flex">
                            <span className="bg-gray-100 flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300">-</span>
                            <input 
                              type="number" 
                              value={Math.abs(xpLatePayment)} 
                              min="0"
                              onChange={(e) => setXpLatePayment(-parseInt(e.target.value))}
                              className="w-full border border-gray-300 rounded-r-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">โพสต์ได้รับไลค์</label>
                          <div className="flex">
                            <span className="bg-gray-100 flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300">+</span>
                            <input 
                              type="number" 
                              value={xpPostLike} 
                              min="0"
                              onChange={(e) => setXpPostLike(parseInt(e.target.value))}
                              className="w-full border border-gray-300 rounded-r-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">โพสต์ได้รับดิสไลค์</label>
                          <div className="flex">
                            <span className="bg-gray-100 flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300">-</span>
                            <input 
                              type="number" 
                              value={Math.abs(xpPostDislike)} 
                              min="0"
                              onChange={(e) => setXpPostDislike(-parseInt(e.target.value))}
                              className="w-full border border-gray-300 rounded-r-lg px-3 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <button 
                        className="bg-primary text-white px-6 py-2 rounded-lg font-medium hover:bg-primary/90"
                        onClick={handleSaveSettings}
                        disabled={updateSettingMutation.isPending}
                      >
                        {updateSettingMutation.isPending ? (
                          <span className="flex items-center">
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            กำลังบันทึก...
                          </span>
                        ) : (
                          "บันทึกการตั้งค่า"
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Other tab content would go here */}
    </>
  );
};

export default Admin;
