import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { register } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { registerUser } from "@/lib/utils";

const Register: React.FC = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Form states
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [bankAccount, setBankAccount] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  // Form step
  const [step, setStep] = useState(1);
  
  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate first step
    if (!email || !password || !confirmPassword || password !== confirmPassword) {
      if (!email) {
        toast({
          title: "กรุณากรอกอีเมล",
          variant: "destructive",
        });
        return;
      }
      
      if (!password) {
        toast({
          title: "กรุณากรอกรหัสผ่าน",
          variant: "destructive",
        });
        return;
      }
      
      if (password !== confirmPassword) {
        toast({
          title: "รหัสผ่านไม่ตรงกัน",
          description: "โปรดตรวจสอบรหัสผ่านอีกครั้ง",
          variant: "destructive",
        });
        return;
      }
    }
    
    setStep(2);
  };
  
  const handlePrevStep = () => {
    setStep(1);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Validate second step
    if (!fullName || !username || !phoneNumber || !bankAccount) {
      toast({
        title: "กรุณากรอกข้อมูลให้ครบถ้วน",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }
    
    try {
      // Register with Firebase
      const result = await register(email, password, fullName);
      
      if (result.error) {
        toast({
          title: "สมัครสมาชิกไม่สำเร็จ",
          description: result.error,
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }
      
      if (result.user) {
        // Register user in our database
        const userData = {
          uid: result.user.uid,
          email,
          fullName,
          username,
          phoneNumber,
          bankAccount,
          level: 1,
          xp: 0,
          onTimeRepayments: 0,
          registrationFee: false,
        };
        
        await registerUser(userData);
        
        toast({
          title: "สมัครสมาชิกสำเร็จ",
          description: "ยินดีต้อนรับเข้าสู่ระบบ SocialLoan",
        });
        
        navigate("/");
      }
    } catch (error: any) {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-light px-4 py-8">
      <div className="w-full max-w-lg">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-primary mb-2">SocialLoan</h1>
            <p className="text-gray-600">สมัครสมาชิกเพื่อเริ่มใช้งาน</p>
          </div>
          
          {/* Step progress */}
          <div className="relative mb-8">
            <div className="flex items-center justify-between">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'}`}>
                1
              </div>
              <div className="flex-1 h-1 mx-2 bg-gray-200">
                <div className={`h-full ${step >= 2 ? 'bg-primary' : 'bg-gray-200'}`} style={{ width: step > 1 ? '100%' : '0%' }}></div>
              </div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'}`}>
                2
              </div>
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-xs text-gray-600">ข้อมูลบัญชี</span>
              <span className="text-xs text-gray-600">ข้อมูลส่วนตัว</span>
            </div>
          </div>
          
          {step === 1 && (
            <form onSubmit={handleNextStep} className="space-y-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  อีเมล
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                  placeholder="your.email@example.com"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  รหัสผ่าน
                </label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                  placeholder="••••••••"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                  ยืนยันรหัสผ่าน
                </label>
                <input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                  placeholder="••••••••"
                  required
                />
              </div>
              
              <button
                type="submit"
                className="w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-primary/90"
              >
                ถัดไป
              </button>
            </form>
          )}
          
          {step === 2 && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                  ชื่อ-นามสกุล
                </label>
                <input
                  id="fullName"
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                  placeholder="ชื่อ นามสกุล"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
                  ชื่อผู้ใช้
                </label>
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                  placeholder="username"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  เบอร์โทรศัพท์
                </label>
                <input
                  id="phoneNumber"
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                  placeholder="0XX-XXX-XXXX"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="bankAccount" className="block text-sm font-medium text-gray-700 mb-1">
                  เลขที่บัญชีธนาคาร
                </label>
                <input
                  id="bankAccount"
                  type="text"
                  value={bankAccount}
                  onChange={(e) => setBankAccount(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:outline-none"
                  placeholder="XXX-X-XXXXX-X"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  บัญชีที่ใช้รับเงินกู้/ชำระเงินต้องเป็นชื่อเดียวกับที่ลงทะเบียน
                </p>
              </div>
              
              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={handlePrevStep}
                  className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200"
                >
                  ย้อนกลับ
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 bg-primary text-white py-3 rounded-lg font-medium hover:bg-primary/90 disabled:opacity-50"
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      กำลังสมัคร...
                    </span>
                  ) : (
                    "สมัครสมาชิก"
                  )}
                </button>
              </div>
            </form>
          )}
          
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              มีบัญชีอยู่แล้ว?{" "}
              <Link href="/login" className="text-primary font-medium hover:underline">
                เข้าสู่ระบบ
              </Link>
            </p>
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-200">
            <div className="text-sm text-gray-500">
              <p className="mb-2">
                โดยการสมัครสมาชิก คุณยอมรับในข้อกำหนดการใช้งานและนโยบายความเป็นส่วนตัวของเรา
              </p>
              <p>
                <strong>หมายเหตุ:</strong> คุณจะต้องชำระค่าสมัครสมาชิก 100 บาทก่อนจึงจะสามารถใช้บริการกู้ยืมเงินได้
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
