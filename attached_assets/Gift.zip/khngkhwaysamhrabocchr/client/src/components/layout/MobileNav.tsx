import React from "react";
import { useLocation } from "wouter";

interface MobileNavProps {
  currentView: string;
}

const MobileNav: React.FC<MobileNavProps> = ({ currentView }) => {
  const [, navigate] = useLocation();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-30">
      <div className="flex justify-between">
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); navigate("/"); }} 
          className={`flex-1 flex flex-col items-center py-2 ${currentView === "dashboard" ? "text-primary" : "text-gray-500"}`}
        >
          <i className="fas fa-home text-xl"></i>
          <span className="text-xs mt-1">ฟีด</span>
        </a>
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); navigate("/loans"); }} 
          className={`flex-1 flex flex-col items-center py-2 ${currentView === "loans" ? "text-primary" : "text-gray-500"}`}
        >
          <i className="fas fa-money-bill-wave text-xl"></i>
          <span className="text-xs mt-1">การเงิน</span>
        </a>
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); navigate("/friends"); }} 
          className={`flex-1 flex flex-col items-center py-2 ${currentView === "friends" ? "text-primary" : "text-gray-500"}`}
        >
          <i className="fas fa-user-friends text-xl"></i>
          <span className="text-xs mt-1">เพื่อน</span>
        </a>
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); navigate("/profile"); }} 
          className={`flex-1 flex flex-col items-center py-2 ${currentView === "profile" ? "text-primary" : "text-gray-500"}`}
        >
          <i className="fas fa-user text-xl"></i>
          <span className="text-xs mt-1">โปรไฟล์</span>
        </a>
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); navigate("/fraud-check"); }} 
          className={`flex-1 flex flex-col items-center py-2 ${currentView === "fraud-check" ? "text-primary" : "text-gray-500"}`}
        >
          <i className="fas fa-shield-alt text-xl"></i>
          <span className="text-xs mt-1">ตรวจสอบ</span>
        </a>
      </div>
    </nav>
  );
};

export default MobileNav;
