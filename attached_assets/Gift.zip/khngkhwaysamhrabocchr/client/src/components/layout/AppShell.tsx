import React from "react";
import Header from "./Header";
import MobileNav from "./MobileNav";
import { useAuth } from "@/context/AuthContext";
import { useLocation, useRoute } from "wouter";

interface AppShellProps {
  children: React.ReactNode;
}

const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const { currentUser, isLoading } = useAuth();
  const [location, navigate] = useLocation();
  const [, params] = useRoute("/:view");
  
  // Default to dashboard if on root
  const currentView = params?.view || (location === "/" ? "dashboard" : location.substring(1));

  React.useEffect(() => {
    if (!isLoading && !currentUser) {
      navigate("/login");
    }
  }, [currentUser, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!currentUser) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="flex flex-col h-screen bg-light">
      <Header currentView={currentView} />
      
      <main className="flex-1 pt-16 pb-16 md:pb-0">
        <div className="container mx-auto px-4 py-6">
          {/* View selector tabs for desktop */}
          <div className="hidden md:flex border-b mb-6">
            <button 
              className={`px-4 py-2 font-medium ${currentView === "dashboard" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => navigate("/")}
            >
              ฟีด
            </button>
            <button 
              className={`px-4 py-2 font-medium ${currentView === "loans" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => navigate("/loans")}
            >
              การเงิน
            </button>
            <button 
              className={`px-4 py-2 font-medium ${currentView === "friends" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => navigate("/friends")}
            >
              เพื่อน
            </button>
            <button 
              className={`px-4 py-2 font-medium ${currentView === "profile" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => navigate("/profile")}
            >
              โปรไฟล์
            </button>
            <button 
              className={`px-4 py-2 font-medium ${currentView === "fraud-check" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-primary"}`}
              onClick={() => navigate("/fraud-check")}
            >
              ตรวจสอบบัญชี
            </button>
          </div>
          
          {children}
        </div>
      </main>
      
      <MobileNav currentView={currentView} />
    </div>
  );
};

export default AppShell;
