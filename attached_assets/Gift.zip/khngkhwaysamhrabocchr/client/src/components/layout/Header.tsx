import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { getInitials, getLevelBadgeColor } from "@/lib/utils";
import { signOut } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface HeaderProps {
  currentView: string;
}

const Header: React.FC<HeaderProps> = ({ currentView }) => {
  const { currentUser, userProfile } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMessages, setShowMessages] = useState(false);
  
  const handleSignOut = async () => {
    const result = await signOut();
    if (result.error) {
      toast({
        title: "Error signing out",
        description: result.error,
        variant: "destructive",
      });
    } else {
      navigate("/login");
    }
  };
  
  const userLevel = userProfile?.level || 1;
  const userName = userProfile?.fullName || currentUser?.displayName || "User";

  return (
    <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-30">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <a href="#" onClick={(e) => { e.preventDefault(); navigate("/"); }} className="text-primary font-bold text-xl">
              SocialLoan
            </a>
          </div>
          
          {/* Search */}
          <div className="hidden md:block flex-1 max-w-md mx-4">
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <i className="fas fa-search text-gray-400"></i>
              </span>
              <input 
                type="text" 
                placeholder="ค้นหาเพื่อน, โพสต์, หรือข้อมูล..." 
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>
          
          {/* Right menu */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <div className="relative">
              <button 
                className="p-2 rounded-full hover:bg-gray-100 relative"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <i className="fas fa-bell text-gray-600"></i>
                <span className="notification-dot"></span>
              </button>
              
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg py-2 z-50">
                  <div className="px-4 py-2 border-b">
                    <h3 className="font-semibold">การแจ้งเตือน</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    <div className="px-4 py-3 hover:bg-gray-50">
                      <div className="font-medium">ถึงกำหนดชำระเงินกู้</div>
                      <div className="text-sm text-gray-500">ครบกำหนดชำระในอีก 3 วัน</div>
                    </div>
                    <div className="px-4 py-3 hover:bg-gray-50">
                      <div className="font-medium">คุณได้รับไลค์</div>
                      <div className="text-sm text-gray-500">กนกพร ถูกใจโพสต์ของคุณ</div>
                    </div>
                  </div>
                  <div className="px-4 py-2 border-t text-center">
                    <button className="text-primary text-sm font-medium">ดูทั้งหมด</button>
                  </div>
                </div>
              )}
            </div>
            
            {/* Messages */}
            <div className="relative">
              <button 
                className="p-2 rounded-full hover:bg-gray-100 relative"
                onClick={() => setShowMessages(!showMessages)}
              >
                <i className="fas fa-comment-alt text-gray-600"></i>
                <span className="notification-dot"></span>
              </button>
              
              {showMessages && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg py-2 z-50">
                  <div className="px-4 py-2 border-b">
                    <h3 className="font-semibold">ข้อความ</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    <div className="px-4 py-3 hover:bg-gray-50">
                      <div className="font-medium">ประวิทย์ สุกใส</div>
                      <div className="text-sm text-gray-500 truncate">สวัสดีครับ ขอสอบถามเรื่องการกู้หน่อย</div>
                    </div>
                    <div className="px-4 py-3 hover:bg-gray-50">
                      <div className="font-medium">กนกพร รักดี</div>
                      <div className="text-sm text-gray-500 truncate">ขอบคุณสำหรับคำแนะนำนะคะ</div>
                    </div>
                  </div>
                  <div className="px-4 py-2 border-t text-center">
                    <button className="text-primary text-sm font-medium">ดูทั้งหมด</button>
                  </div>
                </div>
              )}
            </div>
            
            {/* Profile */}
            <div className="relative">
              <button 
                className="flex items-center space-x-1"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
              >
                <div className="w-9 h-9 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium overflow-hidden">
                  <span>{getInitials(userName)}</span>
                </div>
                <div className="hidden md:flex flex-col items-start">
                  <span className="text-sm font-medium">{userName}</span>
                  <div className="flex items-center">
                    <span className="text-xs text-gray-500">Level <span>{userLevel}</span></span>
                    <div className={`w-2 h-2 rounded-full ${getLevelBadgeColor(userLevel)} ml-1`}></div>
                  </div>
                </div>
              </button>
              
              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                  <a 
                    href="#" 
                    onClick={(e) => { 
                      e.preventDefault(); 
                      navigate("/profile"); 
                      setShowProfileMenu(false);
                    }} 
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    <i className="fas fa-user mr-2"></i> โปรไฟล์
                  </a>
                  <a 
                    href="#" 
                    onClick={(e) => { 
                      e.preventDefault(); 
                      navigate("/loans"); 
                      setShowProfileMenu(false);
                    }} 
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    <i className="fas fa-money-bill-wave mr-2"></i> การเงินของฉัน
                  </a>
                  {userProfile?.email === "admin@example.com" && (
                    <a 
                      href="#" 
                      onClick={(e) => { 
                        e.preventDefault(); 
                        navigate("/admin"); 
                        setShowProfileMenu(false);
                      }} 
                      className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                    >
                      <i className="fas fa-cog mr-2"></i> แผงควบคุมแอดมิน
                    </a>
                  )}
                  <div className="border-t my-1"></div>
                  <a 
                    href="#" 
                    onClick={(e) => { 
                      e.preventDefault(); 
                      handleSignOut();
                      setShowProfileMenu(false);
                    }} 
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    <i className="fas fa-sign-out-alt mr-2"></i> ออกจากระบบ
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
