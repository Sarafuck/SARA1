import React, { useState } from "react";
import { getInitials, getLevelBadgeColor } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";

interface FriendItemProps {
  friend: any;
}

const FriendItem: React.FC<FriendItemProps> = ({ friend }) => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showActions, setShowActions] = useState(false);
  
  // Get the actual friend object (not the relationship)
  const friendId = friend.userId === userProfile?.id ? friend.friendId : friend.userId;
  const friendData = friend.friendData || {
    fullName: "Unknown User",
    level: 1
  };
  
  // Mutation to remove friend
  const removeFriendMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/friends/${friend.id}`);
    },
    onSuccess: () => {
      toast({
        title: "ลบเพื่อนสำเร็จ",
        description: `คุณได้ลบ ${friendData.fullName} ออกจากรายชื่อเพื่อนแล้ว`,
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userProfile?.id}/friends`] });
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Handle chat button click
  const handleChat = () => {
    toast({
      title: "เปิดแชท",
      description: `กำลังเปิดแชทกับ ${friendData.fullName}`,
    });
  };
  
  // Handle more options button click
  const handleMoreOptions = () => {
    setShowActions(!showActions);
  };
  
  // Handle remove friend
  const handleRemoveFriend = () => {
    if (window.confirm(`คุณต้องการลบ ${friendData.fullName} ออกจากรายชื่อเพื่อนหรือไม่?`)) {
      removeFriendMutation.mutate();
    }
  };

  return (
    <div className="border rounded-lg p-3 flex items-center relative">
      <div className={`w-12 h-12 rounded-full ${getLevelBadgeColor(friendData.level)} flex items-center justify-center text-white text-sm font-medium overflow-hidden mr-3`}>
        <span>{getInitials(friendData.fullName)}</span>
      </div>
      <div className="flex-1">
        <div className="font-medium">{friendData.fullName}</div>
        <div className="flex items-center text-xs text-gray-500">
          <span>Level {friendData.level}</span>
          <div className={`w-2 h-2 rounded-full ${getLevelBadgeColor(friendData.level)} ml-1`}></div>
        </div>
      </div>
      <div className="flex space-x-1">
        <button 
          className="p-2 hover:bg-gray-100 rounded-full"
          onClick={handleChat}
        >
          <i className="fas fa-comment-alt text-gray-600"></i>
        </button>
        <button 
          className="p-2 hover:bg-gray-100 rounded-full"
          onClick={handleMoreOptions}
        >
          <i className="fas fa-ellipsis-h text-gray-600"></i>
        </button>
      </div>
      
      {/* Actions dropdown */}
      {showActions && (
        <div className="absolute right-0 top-12 bg-white rounded-lg shadow-lg py-2 z-10 w-48">
          <button 
            className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            onClick={handleRemoveFriend}
            disabled={removeFriendMutation.isPending}
          >
            {removeFriendMutation.isPending ? (
              <span className="flex items-center">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-gray-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                กำลังลบเพื่อน...
              </span>
            ) : (
              <><i className="fas fa-user-times mr-2"></i> ลบเพื่อน</>
            )}
          </button>
          <button className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
            <i className="fas fa-eye mr-2"></i> ดูโปรไฟล์
          </button>
          <button 
            className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            onClick={() => setShowActions(false)}
          >
            <i className="fas fa-times mr-2"></i> ปิด
          </button>
        </div>
      )}
    </div>
  );
};

export default FriendItem;
