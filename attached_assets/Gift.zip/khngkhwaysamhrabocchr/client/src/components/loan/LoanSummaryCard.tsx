import React from "react";
import { formatCurrency } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { useLocation } from "wouter";

interface LoanSummaryCardProps {
  availableAmount: number;
  maxAmount: number;
  currentLoan?: any;
}

const LoanSummaryCard: React.FC<LoanSummaryCardProps> = ({ 
  availableAmount, 
  maxAmount, 
  currentLoan 
}) => {
  const { userProfile } = useAuth();
  const [, navigate] = useLocation();
  
  // Calculate available percentage
  const availablePercentage = (availableAmount / maxAmount) * 100;
  const usedPercentage = 100 - availablePercentage;
  
  // Calculate loan progress if there's a current loan
  const loanProgress = currentLoan ? (currentLoan.installmentsPaid / currentLoan.duration) * 100 : 0;

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4">สรุปเงินกู้</h2>
      <div className="space-y-4">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium">ยอดเงินที่ใช้ได้</span>
            <span className="text-xl font-bold">{formatCurrency(availableAmount)}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-secondary h-2.5 rounded-full" 
              style={{ width: `${availablePercentage}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs mt-1">
            <span>วงเงินสูงสุด: {formatCurrency(maxAmount)}</span>
            <span>ใช้ไป {usedPercentage}%</span>
          </div>
        </div>
        
        {/* Current loan */}
        {currentLoan ? (
          <div className="border rounded-lg p-3">
            <div className="flex justify-between">
              <span className="text-sm font-medium">เงินกู้ปัจจุบัน</span>
              <span className="bg-accent/10 text-accent px-2 py-0.5 rounded text-xs font-medium">กำลังผ่อนชำระ</span>
            </div>
            <div className="mt-2">
              <div className="text-xl font-bold">{formatCurrency(currentLoan.amount)}</div>
              <div className="flex justify-between text-sm text-gray-500 mt-1">
                <span>ดอกเบี้ย {currentLoan.interestRate}%</span>
                <span>ชำระแล้ว {currentLoan.installmentsPaid}/{currentLoan.duration} งวด</span>
              </div>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-sm mb-1">
                <span>ความคืบหน้า</span>
                <span>{Math.round(loanProgress)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-accent h-2 rounded-full" 
                  style={{ width: `${loanProgress}%` }}
                ></div>
              </div>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-sm">
                <span>กำหนดชำระครั้งต่อไป</span>
                <span className="font-medium">
                  {currentLoan.nextPaymentDate ? new Date(currentLoan.nextPaymentDate).toLocaleDateString('th-TH') : 'ไม่มีข้อมูล'}
                </span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span>จำนวนเงิน</span>
                <span className="font-medium">
                  {formatCurrency(currentLoan.amount / currentLoan.duration + (currentLoan.amount * currentLoan.interestRate / 100 / currentLoan.duration))}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="border rounded-lg p-4 text-center">
            <p className="text-gray-500 mb-2">คุณยังไม่มีเงินกู้ที่กำลังผ่อนชำระอยู่</p>
          </div>
        )}
        
        {/* Action buttons */}
        <div className="flex space-x-2">
          <button 
            className="flex-1 bg-primary text-white py-2 px-4 rounded-lg font-medium hover:bg-primary/90"
            onClick={() => navigate("/loans")}
          >
            ขอกู้เงิน
          </button>
          {currentLoan && (
            <button className="flex-1 border border-primary text-primary py-2 px-4 rounded-lg font-medium hover:bg-primary/5">
              ชำระเงิน
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoanSummaryCard;
