import React, { useState, useEffect } from "react";
import { formatCurrency, calculateInstallment, getInterestRateByLevel, getInterestRates } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const LoanRequestForm: React.FC = () => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [amount, setAmount] = useState(5000);
  const [duration, setDuration] = useState(3);
  const [purpose, setPurpose] = useState("personal");
  const [interestRates, setInterestRates] = useState({ level1: 5, level2: 3, level3: 2, level4: 1 });
  const [maxAmount, setMaxAmount] = useState(20000);
  
  // Calculate max amount based on user level
  useEffect(() => {
    if (userProfile) {
      // Set max loan amount based on user level
      const baseAmount = 10000;
      const levelMultiplier = userProfile.level;
      setMaxAmount(baseAmount * levelMultiplier);
      
      // Fetch interest rates
      getInterestRates().then(rates => {
        setInterestRates(rates);
      });
    }
  }, [userProfile]);
  
  // Get interest rate based on user level
  const interestRate = userProfile ? getInterestRateByLevel(interestRates, userProfile.level) : 5;
  
  // Calculate fees and total
  const interest = amount * (interestRate / 100);
  const fee = 100; // Fixed fee
  const totalAmount = amount + interest + fee;
  const monthlyPayment = calculateInstallment(amount, interestRate, duration);
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value >= 0) {
      setAmount(Math.min(value, maxAmount));
    }
  };
  
  const createLoanMutation = useMutation({
    mutationFn: async () => {
      if (!userProfile?.id) {
        throw new Error("You must be logged in to request a loan");
      }
      
      return apiRequest("POST", "/api/loans", {
        userId: userProfile.id,
        amount,
        interestRate,
        totalAmount,
        duration,
        purpose,
        status: "pending",
        installmentsPaid: 0,
        nextPaymentDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      });
    },
    onSuccess: () => {
      toast({
        title: "คำขอกู้เงินสำเร็จ",
        description: "คำขอของคุณถูกส่งเรียบร้อยแล้ว เราจะแจ้งผลให้ทราบเร็วๆ นี้",
      });
      
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userProfile?.id}/loans`] });
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (amount <= 0) {
      toast({
        title: "จำนวนเงินไม่ถูกต้อง",
        description: "กรุณาระบุจำนวนเงินที่ต้องการกู้",
        variant: "destructive",
      });
      return;
    }
    
    if (amount > maxAmount) {
      toast({
        title: "จำนวนเงินเกินวงเงิน",
        description: `จำนวนเงินที่ขอกู้เกินวงเงินสูงสุดของคุณ (${formatCurrency(maxAmount)})`,
        variant: "destructive",
      });
      return;
    }
    
    // Check if registration fee is paid
    if (!userProfile?.registrationFee) {
      toast({
        title: "ยังไม่ได้ชำระค่าสมัครสมาชิก",
        description: "คุณต้องชำระค่าสมัครสมาชิกก่อนจึงจะสามารถขอกู้เงินได้",
        variant: "destructive",
      });
      return;
    }
    
    createLoanMutation.mutate();
  };

  return (
    <div className="border-b pb-6 mb-6">
      <h3 className="text-lg font-semibold mb-4">ขอกู้เงินใหม่</h3>
      <form className="space-y-4" onSubmit={handleSubmit}>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">จำนวนเงิน</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">฿</span>
            <input 
              type="number" 
              className="pl-8 w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:outline-none" 
              placeholder="ระบุจำนวนเงิน"
              value={amount}
              onChange={handleAmountChange}
              min={1000}
              max={maxAmount}
              step={1000}
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">วงเงินสูงสุดของคุณ: {formatCurrency(maxAmount)}</p>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">ระยะเวลาผ่อนชำระ</label>
          <select 
            className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:outline-none"
            value={duration}
            onChange={(e) => setDuration(parseInt(e.target.value))}
          >
            <option value={3}>3 เดือน</option>
            <option value={6}>6 เดือน</option>
            <option value={12}>12 เดือน</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">วัตถุประสงค์</label>
          <select 
            className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-primary focus:outline-none"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value)}
          >
            <option value="education">การศึกษา</option>
            <option value="business">ธุรกิจ</option>
            <option value="personal">ส่วนตัว</option>
            <option value="emergency">ฉุกเฉิน</option>
          </select>
        </div>
        
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-2">สรุปการกู้</h4>
          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex justify-between text-sm mb-1">
              <span>ดอกเบี้ย ({interestRate}%)</span>
              <span>{formatCurrency(interest)}</span>
            </div>
            <div className="flex justify-between text-sm mb-1">
              <span>ค่าธรรมเนียม</span>
              <span>{formatCurrency(fee)}</span>
            </div>
            <div className="flex justify-between font-medium mt-2">
              <span>ยอดรวมที่ต้องชำระ</span>
              <span>{formatCurrency(totalAmount)}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-500 mt-1">
              <span>ผ่อนชำระรายเดือน</span>
              <span>{formatCurrency(monthlyPayment)}</span>
            </div>
          </div>
        </div>
        
        <div className="pt-2">
          <button 
            type="submit"
            className="w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-primary/90"
            disabled={createLoanMutation.isPending}
          >
            {createLoanMutation.isPending ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                กำลังดำเนินการ...
              </span>
            ) : "ยืนยันการขอกู้เงิน"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default LoanRequestForm;
