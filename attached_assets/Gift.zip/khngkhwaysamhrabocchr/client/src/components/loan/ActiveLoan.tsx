import React from "react";
import { formatCurrency } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ActiveLoanProps {
  loan: any;
}

const ActiveLoan: React.FC<ActiveLoanProps> = ({ loan }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Calculate progress percentage
  const progress = (loan.installmentsPaid / loan.duration) * 100;
  
  // Calculate next payment amount
  const monthlyPayment = loan.amount / loan.duration;
  const interestPayment = (loan.amount * loan.interestRate / 100) / loan.duration;
  const totalMonthlyPayment = monthlyPayment + interestPayment;
  
  // Payment mutation
  const makePaymentMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/payments", {
        loanId: loan.id,
        userId: loan.userId,
        amount: totalMonthlyPayment,
        onTime: true // Assuming the payment is on time when made through the app
      });
    },
    onSuccess: () => {
      toast({
        title: "ชำระเงินสำเร็จ",
        description: "ระบบได้บันทึกการชำระเงินของคุณเรียบร้อยแล้ว",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${loan.userId}/loans`] });
      queryClient.invalidateQueries({ queryKey: [`/api/loans/${loan.id}/payments`] });
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handlePayment = () => {
    makePaymentMutation.mutate();
  };
  
  const handleViewDetails = () => {
    // View loan details functionality
    toast({
      title: "ดูรายละเอียดเงินกู้",
      description: `เงินกู้ #${loan.id}`,
    });
  };

  return (
    <div className="border rounded-lg p-4 mb-4">
      <div className="flex justify-between items-start">
        <div>
          <div className="font-medium">เงินกู้ #{loan.id}</div>
          <div className="text-sm text-gray-500">วันที่อนุมัติ: {new Date(loan.createdAt).toLocaleDateString('th-TH')}</div>
        </div>
        <span className="bg-accent/10 text-accent px-2 py-1 rounded text-sm font-medium">กำลังผ่อนชำระ</span>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
        <div>
          <div className="text-sm text-gray-500">จำนวนเงิน</div>
          <div className="font-semibold">{formatCurrency(loan.amount)}</div>
        </div>
        <div>
          <div className="text-sm text-gray-500">ระยะเวลา</div>
          <div className="font-semibold">{loan.duration} เดือน</div>
        </div>
        <div>
          <div className="text-sm text-gray-500">ดอกเบี้ย</div>
          <div className="font-semibold">{loan.interestRate}%</div>
        </div>
        <div>
          <div className="text-sm text-gray-500">ชำระแล้ว</div>
          <div className="font-semibold">{loan.installmentsPaid}/{loan.duration} งวด</div>
        </div>
      </div>
      
      <div className="mt-4">
        <div className="flex justify-between text-sm mb-1">
          <span>ความคืบหน้า</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>
      
      <div className="mt-4 flex">
        <button 
          className="flex-1 bg-primary text-white py-2 rounded-lg font-medium hover:bg-primary/90 mr-2"
          onClick={handlePayment}
          disabled={makePaymentMutation.isPending}
        >
          {makePaymentMutation.isPending ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              กำลังชำระเงิน...
            </span>
          ) : (
            "ชำระงวดถัดไป"
          )}
        </button>
        <button 
          className="flex-1 border border-primary text-primary py-2 rounded-lg font-medium hover:bg-primary/5"
          onClick={handleViewDetails}
        >
          ดูรายละเอียด
        </button>
      </div>
    </div>
  );
};

export default ActiveLoan;
