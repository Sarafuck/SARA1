import React from "react";
import { getLevelName, getLevelBadgeColor } from "@/lib/utils";

interface UserLevelCardProps {
  user: any;
  interestRate: number;
}

const UserLevelCard: React.FC<UserLevelCardProps> = ({ user, interestRate }) => {
  // Calculate progress percentage
  const getProgressPercentage = () => {
    if (user.level === 1) {
      return (user.onTimeRepayments / 2) * 100; // Level 1 -> 2 requires 2 on-time repayments
    } else if (user.level === 2) {
      return (user.onTimeRepayments / 5) * 100; // Level 2 -> 3 requires 5 on-time repayments
    } else if (user.level === 3) {
      return (user.onTimeRepayments / 15) * 100; // Level 3 -> 4 requires 15 on-time repayments
    } else {
      return 100; // Max level
    }
  };
  
  const progress = getProgressPercentage();
  
  // Calculate repayments needed for next level
  const getNextLevelRequirements = () => {
    if (user.level === 1) {
      const needed = Math.max(0, 2 - user.onTimeRepayments);
      return { current: user.onTimeRepayments, needed, next: 2, nextLevel: 2 };
    } else if (user.level === 2) {
      const needed = Math.max(0, 5 - user.onTimeRepayments);
      return { current: user.onTimeRepayments, needed, next: 5, nextLevel: 3 };
    } else if (user.level === 3) {
      const needed = Math.max(0, 15 - user.onTimeRepayments);
      return { current: user.onTimeRepayments, needed, next: 15, nextLevel: 4 };
    } else {
      return { current: user.onTimeRepayments, needed: 0, next: 0, nextLevel: 0 };
    }
  };
  
  const nextLevel = getNextLevelRequirements();

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4">ระดับสมาชิก</h2>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center">
          <div className={`w-12 h-12 rounded-full ${getLevelBadgeColor(user.level)} flex items-center justify-center text-white font-bold text-xl`}>
            <span>{user.level}</span>
          </div>
          <div className="ml-3">
            <div className="font-medium">ระดับ {getLevelName(user.level)}</div>
            <div className="text-sm text-gray-500">คืนเงินตรงเวลา {user.onTimeRepayments} ครั้ง</div>
          </div>
        </div>
        <div>
          <span className="bg-secondary/10 text-secondary px-3 py-1 rounded-full text-sm font-medium">
            ดอกเบี้ย {interestRate}%
          </span>
        </div>
      </div>
      
      {user.level < 4 && (
        <>
          {/* Level progress */}
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-1">
              <div>ความก้าวหน้า</div>
              <div>{nextLevel.current}/{nextLevel.next} ครั้ง</div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-primary h-2.5 rounded-full" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <div className="text-sm text-gray-500 mt-1">
              อีก {nextLevel.needed} ครั้งเพื่อขึ้นเป็น Level {nextLevel.nextLevel}
            </div>
          </div>
        </>
      )}
      
      {/* XP status */}
      <div className="mt-4">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium">XP ปัจจุบัน</span>
          <span className="text-primary font-semibold">{user.xp} XP</span>
        </div>
      </div>
    </div>
  );
};

export default UserLevelCard;
