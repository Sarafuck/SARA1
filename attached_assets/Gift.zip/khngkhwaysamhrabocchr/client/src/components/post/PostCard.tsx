import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { formatDate, getInitials, getLevelBadgeColor } from "@/lib/utils";
import CommentSection from "./CommentSection";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface PostCardProps {
  post: any;
  userData: any;
}

const PostCard: React.FC<PostCardProps> = ({ post, userData }) => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showComments, setShowComments] = useState(false);
  
  const { data: likesCount = post.likes } = useQuery({
    queryKey: [`/api/posts/${post.id}/likes`],
    initialData: post.likes,
    enabled: false // Don't fetch automatically
  });
  
  const { data: dislikesCount = post.dislikes } = useQuery({
    queryKey: [`/api/posts/${post.id}/dislikes`],
    initialData: post.dislikes,
    enabled: false // Don't fetch automatically
  });
  
  const { data: comments = [] } = useQuery({
    queryKey: [`/api/posts/${post.id}/comments`],
    queryFn: async () => {
      const response = await fetch(`/api/posts/${post.id}/comments`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch comments");
      return response.json();
    },
    enabled: showComments
  });
  
  const likeMutation = useMutation({
    mutationFn: async () => {
      if (!userProfile?.id) {
        throw new Error("You must be logged in to like posts");
      }
      return apiRequest("POST", `/api/posts/${post.id}/like`, { userId: userProfile.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${post.id}/likes`] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${post.userId}/posts`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to like post",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const dislikeMutation = useMutation({
    mutationFn: async () => {
      if (!userProfile?.id) {
        throw new Error("You must be logged in to dislike posts");
      }
      return apiRequest("POST", `/api/posts/${post.id}/dislike`, { userId: userProfile.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${post.id}/dislikes`] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${post.userId}/posts`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to dislike post",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleLike = () => {
    if (likeMutation.isPending) return;
    likeMutation.mutate();
  };
  
  const handleDislike = () => {
    if (dislikeMutation.isPending) return;
    dislikeMutation.mutate();
  };
  
  const handleToggleComments = () => {
    setShowComments(!showComments);
  };
  
  // Use post user data if available, otherwise use placeholder
  const postUser = userData || {
    fullName: "Unknown User",
    level: 1
  };

  return (
    <div className="bg-white rounded-lg shadow mb-6">
      <div className="p-4">
        {/* Post header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-full ${postUser.id === userProfile?.id ? 'bg-primary' : 'bg-gray-200'} ${postUser.id === userProfile?.id ? 'text-white' : 'text-gray-700'} flex items-center justify-center text-sm font-medium overflow-hidden`}>
              <span>{getInitials(postUser.fullName)}</span>
            </div>
            <div>
              <div className="font-medium">{postUser.fullName}</div>
              <div className="text-xs text-gray-500 flex items-center">
                <span>{formatDate(post.createdAt)}</span>
                <div className="mx-1">•</div>
                <div className="flex items-center">
                  <span>Level {postUser.level}</span>
                  <div className={`w-2 h-2 rounded-full ${getLevelBadgeColor(postUser.level)} ml-1`}></div>
                </div>
              </div>
            </div>
          </div>
          <button className="p-2 hover:bg-gray-100 rounded-full">
            <i className="fas fa-ellipsis-h text-gray-500"></i>
          </button>
        </div>
        
        {/* Post content */}
        <div className="mb-4">
          <p className="mb-4">{post.content}</p>
        </div>
        
        {/* Post stats */}
        <div className="flex justify-between text-sm text-gray-500 py-2 border-t border-b">
          <div>
            <span>{likesCount} ไลค์</span>
          </div>
          <div>
            <span>{comments.length} ความคิดเห็น</span>
          </div>
        </div>
        
        {/* Post actions */}
        <div className="flex justify-between pt-2">
          <button 
            className="flex-1 py-2 text-center hover:bg-gray-100 rounded font-medium text-gray-500" 
            onClick={handleLike}
            disabled={likeMutation.isPending}
          >
            <i className="far fa-thumbs-up mr-1"></i> ถูกใจ
          </button>
          <button 
            className="flex-1 py-2 text-center hover:bg-gray-100 rounded font-medium text-gray-500" 
            onClick={handleDislike}
            disabled={dislikeMutation.isPending}
          >
            <i className="far fa-thumbs-down mr-1"></i> ไม่ถูกใจ
          </button>
          <button 
            className="flex-1 py-2 text-center hover:bg-gray-100 rounded font-medium text-gray-500" 
            onClick={handleToggleComments}
          >
            <i className="far fa-comment mr-1"></i> แสดงความคิดเห็น
          </button>
        </div>
        
        {/* Comments section */}
        {showComments && (
          <CommentSection postId={post.id} comments={comments} />
        )}
      </div>
    </div>
  );
};

export default PostCard;
