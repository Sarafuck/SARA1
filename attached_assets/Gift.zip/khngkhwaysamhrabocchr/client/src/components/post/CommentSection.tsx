import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { getInitials, formatDate } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CommentSectionProps {
  postId: number;
  comments: any[];
}

const CommentSection: React.FC<CommentSectionProps> = ({ postId, comments }) => {
  const { userProfile } = useAuth();
  const [commentText, setCommentText] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const createCommentMutation = useMutation({
    mutationFn: async () => {
      if (!userProfile?.id) {
        throw new Error("You must be logged in to comment");
      }
      
      return apiRequest("POST", `/api/posts/${postId}/comments`, {
        userId: userProfile.id,
        content: commentText
      });
    },
    onSuccess: () => {
      setCommentText("");
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to post comment",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!commentText.trim()) {
      return;
    }
    
    createCommentMutation.mutate();
  };

  return (
    <div className="mt-3 pt-3 border-t">
      {/* Comment form */}
      <div className="flex space-x-2 mb-3">
        <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm">
          <span>{getInitials(userProfile?.fullName || "")}</span>
        </div>
        <form className="flex-1 relative" onSubmit={handleSubmitComment}>
          <input 
            type="text" 
            placeholder="เขียนความคิดเห็น..." 
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            className="w-full pl-3 pr-10 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <button 
            type="submit" 
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-primary"
            disabled={createCommentMutation.isPending}
          >
            <i className="fas fa-paper-plane"></i>
          </button>
        </form>
      </div>
      
      {/* Comment list */}
      <div className="space-y-3">
        {comments.length === 0 ? (
          <div className="text-center text-gray-500 py-3">
            ยังไม่มีความคิดเห็น เป็นคนแรกที่แสดงความคิดเห็น
          </div>
        ) : (
          comments.map((comment) => (
            <div key={comment.id} className="flex space-x-2">
              <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-sm">
                <span>{comment.userName?.[0] || "?"}</span>
              </div>
              <div className="flex-1">
                <div className="bg-gray-100 px-3 py-2 rounded-2xl">
                  <div className="font-medium text-sm">{comment.userName || "User"}</div>
                  <p className="text-sm">{comment.content}</p>
                </div>
                <div className="flex items-center space-x-3 mt-1 text-xs">
                  <button className="text-gray-500 hover:text-primary">ถูกใจ</button>
                  <button className="text-gray-500 hover:text-primary">ตอบกลับ</button>
                  <span className="text-gray-400">{formatDate(comment.createdAt)}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default CommentSection;
