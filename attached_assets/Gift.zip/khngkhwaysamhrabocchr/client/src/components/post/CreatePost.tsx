import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { getInitials } from "@/lib/utils";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const CreatePost: React.FC = () => {
  const { userProfile } = useAuth();
  const [content, setContent] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const createPostMutation = useMutation({
    mutationFn: async () => {
      if (!userProfile?.id) {
        throw new Error("You must be logged in to create a post");
      }
      
      return apiRequest("POST", "/api/posts", {
        userId: userProfile.id,
        content
      });
    },
    onSuccess: () => {
      setContent("");
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userProfile?.id}/posts`] });
      
      toast({
        title: "โพสต์สำเร็จ",
        description: "โพสต์ของคุณถูกสร้างเรียบร้อยแล้ว",
      });
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim()) {
      toast({
        title: "เนื้อหาว่างเปล่า",
        description: "กรุณาเพิ่มเนื้อหาในโพสต์ของคุณ",
        variant: "destructive",
      });
      return;
    }
    
    createPostMutation.mutate();
  };

  return (
    <div className="bg-white rounded-lg shadow mb-6 p-4">
      <div className="flex items-start space-x-3">
        <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium overflow-hidden">
          <span>{getInitials(userProfile?.fullName || "")}</span>
        </div>
        <div className="flex-1">
          <textarea 
            placeholder="คุณกำลังคิดอะไรอยู่?" 
            rows={3} 
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary resize-none"
          ></textarea>
          
          <div className="flex justify-between items-center mt-3">
            <div className="flex space-x-2">
              <button className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                <i className="fas fa-image"></i>
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                <i className="fas fa-video"></i>
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                <i className="fas fa-link"></i>
              </button>
            </div>
            <button 
              className="bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-primary/90"
              onClick={handleSubmit}
              disabled={createPostMutation.isPending}
            >
              {createPostMutation.isPending ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  กำลังโพสต์...
                </span>
              ) : "โพสต์"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatePost;
