/**
 * Formats a date into Thai-friendly format with relative time
 * @param date Date to format
 * @returns Formatted date string
 */
export function formatDate(date: Date | string | number): string {
  const d = new Date(date);
  
  // Check if date is valid
  if (isNaN(d.getTime())) {
    return "Invalid date";
  }
  
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  const diffMonths = (now.getFullYear() - d.getFullYear()) * 12 + now.getMonth() - d.getMonth();
  
  // Format: less than a minute ago
  if (diffSecs < 60) {
    return "เมื่อสักครู่";
  }
  // Format: X minutes ago
  else if (diffMins < 60) {
    return `${diffMins} นาทีที่แล้ว`;
  }
  // Format: X hours ago
  else if (diffHours < 24) {
    return `${diffHours} ชั่วโมงที่แล้ว`;
  }
  // Format: X days ago
  else if (diffDays < 30) {
    return `${diffDays} วันที่แล้ว`;
  }
  // Format: X months ago
  else if (diffMonths < 12) {
    return `${diffMonths} เดือนที่แล้ว`;
  }
  // Format: date in thai format (day month year)
  else {
    const day = d.getDate();
    const month = getThaiMonth(d.getMonth());
    const year = d.getFullYear() + 543; // Convert to Buddhist Era
    return `${day} ${month} ${year}`;
  }
}

/**
 * Gets Thai month abbreviation from month index
 * @param month Month index (0-11)
 * @returns Thai month abbreviation
 */
function getThaiMonth(month: number): string {
  const months = [
    "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.",
    "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."
  ];
  return months[month];
}
