import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/context/AuthContext";

import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Loans from "@/pages/Loans";
import Friends from "@/pages/Friends";
import Profile from "@/pages/Profile";
import FraudCheck from "@/pages/FraudCheck";
import Admin from "@/pages/Admin";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import AppShell from "@/components/layout/AppShell";

function ProtectedRoute({ component: Component, ...rest }: { component: React.ComponentType<any>, [x: string]: any }) {
  const { currentUser, isLoading } = useAuth();
  const [, navigate] = useLocation();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>;
  }

  if (!currentUser) {
    navigate("/login");
    return null;
  }

  return <Component {...rest} />;
}

function AdminRoute({ component: Component, ...rest }: { component: React.ComponentType<any>, [x: string]: any }) {
  const { userProfile, isLoading } = useAuth();
  const [, navigate] = useLocation();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>;
  }

  // For demo purposes, check if user is admin (in real app, this would be a role in the user profile)
  if (!userProfile || userProfile.email !== "admin@example.com") {
    navigate("/");
    return null;
  }

  return <Component {...rest} />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      <Route path="/">
        <AppShell>
          <ProtectedRoute component={Dashboard} />
        </AppShell>
      </Route>
      
      <Route path="/loans">
        <AppShell>
          <ProtectedRoute component={Loans} />
        </AppShell>
      </Route>
      
      <Route path="/friends">
        <AppShell>
          <ProtectedRoute component={Friends} />
        </AppShell>
      </Route>
      
      <Route path="/profile">
        <AppShell>
          <ProtectedRoute component={Profile} />
        </AppShell>
      </Route>
      
      <Route path="/fraud-check">
        <AppShell>
          <ProtectedRoute component={FraudCheck} />
        </AppShell>
      </Route>
      
      <Route path="/admin">
        <AppShell>
          <AdminRoute component={Admin} />
        </AppShell>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
