import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull().unique(), // Firebase UID
  username: text("username").notNull().unique(),
  fullName: text("full_name").notNull(),
  phoneNumber: text("phone_number").notNull(),
  bankAccount: text("bank_account").notNull(),
  email: text("email").notNull(),
  profileImage: text("profile_image"),
  level: integer("level").notNull().default(1),
  xp: integer("xp").notNull().default(0),
  onTimeRepayments: integer("on_time_repayments").notNull().default(0),
  registrationFee: boolean("registration_fee").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Post model
export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // Foreign key to users table
  content: text("content").notNull(),
  likes: integer("likes").notNull().default(0),
  dislikes: integer("dislikes").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
});

// Comment model
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(), // Foreign key to posts table
  userId: integer("user_id").notNull(), // Foreign key to users table
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
});

// Friend model (for friend relationships)
export const friends = pgTable("friends", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // User who sent/received request
  friendId: integer("friend_id").notNull(), // The friend
  status: text("status").notNull(), // "pending", "accepted", "rejected"
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFriendSchema = createInsertSchema(friends).omit({
  id: true,
  createdAt: true,
});

// Loan model
export const loans = pgTable("loans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // Foreign key to users table
  amount: doublePrecision("amount").notNull(),
  interestRate: doublePrecision("interest_rate").notNull(),
  totalAmount: doublePrecision("total_amount").notNull(),
  duration: integer("duration").notNull(), // Duration in months
  purpose: text("purpose").notNull(),
  status: text("status").notNull(), // "pending", "approved", "active", "completed", "defaulted"
  installmentsPaid: integer("installments_paid").notNull().default(0),
  nextPaymentDate: timestamp("next_payment_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLoanSchema = createInsertSchema(loans).omit({
  id: true,
  createdAt: true,
});

// Payment model
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  loanId: integer("loan_id").notNull(), // Foreign key to loans table
  userId: integer("user_id").notNull(), // Foreign key to users table
  amount: doublePrecision("amount").notNull(),
  onTime: boolean("on_time").notNull().default(false),
  paymentDate: timestamp("payment_date").notNull().defaultNow(),
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  paymentDate: true,
});

// Fraud Report model
export const fraudReports = pgTable("fraud_reports", {
  id: serial("id").primaryKey(),
  reporterId: integer("reporter_id").notNull(), // User who reported
  fullName: text("full_name"),
  phoneNumber: text("phone_number"),
  bankAccount: text("bank_account"),
  reportType: text("report_type").notNull(), // "not_pay", "late", "scam", "other"
  details: text("details"),
  evidence: text("evidence"), // URL to evidence file
  status: text("status").notNull().default("pending"), // "pending", "verified", "rejected"
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFraudReportSchema = createInsertSchema(fraudReports).omit({
  id: true,
  status: true,
  createdAt: true,
});

// System Settings model
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type Friend = typeof friends.$inferSelect;
export type InsertFriend = z.infer<typeof insertFriendSchema>;

export type Loan = typeof loans.$inferSelect;
export type InsertLoan = z.infer<typeof insertLoanSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type FraudReport = typeof fraudReports.$inferSelect;
export type InsertFraudReport = z.infer<typeof insertFraudReportSchema>;

export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;
